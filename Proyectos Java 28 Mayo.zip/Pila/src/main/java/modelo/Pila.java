package main.java.modelo;

public class Pila {

	public Pila () {
		
	}
}
