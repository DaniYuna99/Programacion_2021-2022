package dbconnect.main.java.api;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Scanner;

import dbconnect.main.java.model.Cliente;

public class Connector {
	
	
	private static String USER;
	private final static String DB_USER_KEY="db.user";

	private static String PASS;
	private final static String DB_PASS_KEY="db.pass";
	
	private static String JDBC_URL;
	private final static String DB_URL_KEY="db.url";
	
	private final static String PROPERTIES_URI = "./resources/db.properties";
	
	private final static String SEPARADOR = "----------------------------------------------------------------------------";
	
	
	public Connector() {
		super();
		loadProperties();
	}
	
	
	public void loadProperties() {
		
		try {
			Properties properties = new Properties();
			properties.load(new FileReader(PROPERTIES_URI));
			USER = properties.getProperty(DB_USER_KEY);
			PASS = properties.getProperty(DB_PASS_KEY);
			JDBC_URL = properties.getProperty(DB_URL_KEY);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	//APARTADO 1
	public void mostrarDatosClientes() throws SQLException {
		
		Connection conexion = DriverManager.getConnection(JDBC_URL, USER, PASS);
		Statement statement= conexion.createStatement();
		ResultSet rs = statement.executeQuery("select * from Cliente");
		
		System.out.println("NOMBRE - APELLIDOS - EMAIL - FECHA DE NACIMIENTO - G�NERO");
		System.out.println(SEPARADOR);
		
		while(rs.next()) {	
			Cliente cliente = new Cliente(Integer.valueOf(rs.getString(1)), rs.getString(2), rs.getString(3), rs.getString(4), 
										rs.getString(5), rs.getString(6));
			System.out.println(cliente.getNombre() + " - " +
								cliente.getApellidos() + " - " +
								cliente.getEmail() + " - " +
								cliente.getFechaNacimiento() + " - " +
								cliente.getGenero());
			System.out.println(SEPARADOR);
		}
		
		conexion.close();  
		statement.close();
		rs.close();

	}
	
	
	//APARTADO 2
	public void mostrarPedidosPorImporteDecreciente() throws SQLException {
		
		Connection conexion = DriverManager.getConnection(JDBC_URL, USER, PASS);
		Statement statement = conexion.createStatement();
		ResultSet rs = statement.executeQuery(
				"select p.codigo, p.status, c.nombre, c.apellido, "
				+ "COUNT(p.id), l.precio "
				+ "from Cliente c, Pedido p, Linea l "
				+ "where c.id = p.idCliente "
				+ "and p.id = l.idPedido "
				+ "group by p.codigo, p.status, c.nombre, c.apellido, l.precio "
				+ "order by l.precio desc");
		
		while(rs.next()) {
			System.out.println(rs.getString(1) + " - " + rs.getString(2) + " - " + rs.getString(3) + " - " + 
						rs.getString(4) + " - " + Integer.valueOf(rs.getString(5)) + " - " + rs.getString(6));
			System.out.println(SEPARADOR);
		}
		
		conexion.close();
		statement.close();
		rs.close();
	}
	

	//APARTADO 3 (Salta una Exception tras usar la funci�n, pero funciona) 
	public void anadirCliente() throws SQLException {
		
		Connection conexion = DriverManager.getConnection(JDBC_URL, USER, PASS);
		PreparedStatement ps = conexion.prepareStatement("insert into Cliente (nombre, apellido, email, fechaNacimiento, genero) values (?, ?, ?, ?, ?)");
		
		Scanner sc = new Scanner(System.in);
		
		//Insertar nombre
		System.out.println("Introduce nombre: ");
		String nombre = String.valueOf(sc.nextLine());
		ps.setString(1, nombre);
		
		//Insertar apellido
		System.out.println("Introduce apellido: ");
		String apellido = String.valueOf(sc.nextLine());
		ps.setString(2, apellido);
		
		//Insertar email
		System.out.println("Introduce email: ");
		String email = String.valueOf(sc.nextLine());
		ps.setString(3, email);
		
		//Insertar fecha
		System.out.println("Introduce d�a de nacimiento: ");
		int dia = Integer.valueOf(sc.nextLine());
		System.out.println("Introduce mes de nacimiento: ");
		int mes = Integer.valueOf(sc.nextLine());
		System.out.println("Introduce a�o de nacimiento: ");
		int ano = Integer.valueOf(sc.nextLine());
		@SuppressWarnings("deprecation")
		Date fechaNac = new Date (ano, mes, dia);
		ps.setDate(4, fechaNac);
		
		//Insertar genero
		System.out.println("Introduce g�nero (M/F): ");
		String genero = String.valueOf(sc.nextLine());
		ps.setString(5, genero);
		
		//Ejecutar el insert creado
		ps.executeUpdate();
		
		System.out.println("Creado.");

		sc.close();
		conexion.close();
		ps.close();
	}
	
	//APARTADO 4 (ME FALLA LA FECHA, Y NO S� ARREGLAR EL ERROR)
	public void actualizarCliente() throws SQLException {
		
		Connection conexion = DriverManager.getConnection(JDBC_URL, USER, PASS);
		
		Scanner sc = new Scanner(System.in);
		
		//Insertar Id del cliente
		System.out.println("Dime el ID del cliente que quieres actualizar: ");
		int id = Integer.valueOf(sc.nextLine());
		
		//Insertar nombre
		System.out.println("Introduce nombre nuevo: ");
		String nombre = String.valueOf(sc.nextLine());
		
		//Insertar apellido
		System.out.println("Introduce apellido nuevo: ");
		String apellido = String.valueOf(sc.nextLine());
		
		//Insertar email
		System.out.println("Introduce email nuevo: ");
		String email = String.valueOf(sc.nextLine());
		
		//Insertar fecha
		System.out.println("Introduce d�a de nacimiento nuevo: ");
		String dia = String.valueOf(sc.nextLine());
		System.out.println("Introduce mes de nacimiento nuevo: ");
		String mes = String.valueOf(sc.nextLine());
		System.out.println("Introduce a�o de nacimiento nuevo: ");
		String ano = String.valueOf(sc.nextLine());
		//@SuppressWarnings("deprecation")
		//Date fechaNac = new Date (ano, mes, dia);
		
		//Insertar genero
		System.out.println("Introduce g�nero nuevo (M/F): ");
		String genero = String.valueOf(sc.nextLine());

		
		PreparedStatement ps = conexion.prepareStatement(
				"update Cliente "
				+ "set nombre = " + nombre + ","
				+ "apellido = " + apellido + ","
				+ "email = " + email + "," 
				+ "fechaNacimiento = " 
				+ "STR_TO_DATE('" + ano + " " + mes + " " + dia + "', '%Y %m %d')" + ","
				+ "genero = " + genero + " "
				+ "where id = " + id);
		
		//Ejecutar el update creado
		ps.executeUpdate();
		
		sc.close();
		conexion.close();

	}
	
	//APARTADO 5 (SALTA UNA EXCEPTION LLAMADA NoSuchElementException, PERO BORRA EL CLIENTE DE TODAS FORMAS.)
	public void eliminarCliente () throws SQLException {
		
		Connection conexion = DriverManager.getConnection(JDBC_URL, USER, PASS);
		
		Scanner sc = new Scanner(System.in);

		System.out.println("�Cu�l es el cliente que deseas borrar? Dime su ID: ");
		int id = Integer.valueOf(sc.nextLine());
		
		PreparedStatement ps = conexion.prepareStatement("delete from Cliente where id = " + id);
		ps.executeUpdate();
		
		System.out.println("Borrado.");
		
		conexion.close();
		sc.close();

	}
	
	//APARTADO 6 (SALTA UNA EXCEPTION LLAMADA NoSuchElementException, PERO SE INCLUYE EL PEDIDO DE TODAS FORMAS.)
	public void anadirPedido() throws SQLException, NoSuchElementException {
		
		Connection conexion = DriverManager.getConnection(JDBC_URL, USER, PASS);
		PreparedStatement ps = conexion.prepareStatement("insert into Pedido (codigo, status, idCliente) "
												+ "values (?, ?, ?)");
		Scanner sc = new Scanner(System.in);

		System.out.println("�Cu�l es el cliente al que quieres a�adir el pedido? Dime su ID: ");
		int id = Integer.valueOf(sc.nextLine());
		ps.setInt(3, id);

		System.out.println("Dime el c�digo que llevar� el pedido: ");
		String codigo = String.valueOf(sc.nextLine());
		ps.setString(1, codigo);

		System.out.println("Dime el estado del pedido (PENDIENTE, ENVIADO, CANCELADO, PROCESANDO): ");
		String status = String.valueOf(sc.nextLine());
		ps.setString(2, status);
		
		ps.executeUpdate();
		
		System.out.println("Pedido a�adido.");

		conexion.close();
		sc.close();
		ps.close();

	}
	
	
	//APARTADO 7
	public void incluirLineasPedidoEnEstadoProcesando() throws SQLException {
		
		Connection conexion = DriverManager.getConnection(JDBC_URL, USER, PASS);
		Statement statement= conexion.createStatement();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("�Cu�l es el pedido al cu�l le vas a incluir una l�nea? Dime su ID: ");
		int idPedido = Integer.valueOf(sc.nextLine());
		
		ResultSet rs = statement.executeQuery("select status from Pedido where id = " + idPedido);
		System.out.println("A");
		
		if ("PROCESANDO".equals(rs.getString(1))) {
			PreparedStatement ps = conexion.prepareStatement("insert into Linea "
					+ "(codigo, nombreProducto, idPedido, cantidad, precio "
					+ "values (?, ?, ?, ?, ?)");
			
			ps.setInt(3, idPedido);
			
			System.out.println("Dime el c�digo de la nueva l�nea: ");
			String codigo = String.valueOf(sc.nextLine());
			ps.setString(1, codigo);
			
			System.out.println("Dime el nombre del producto: ");
			String nombreProducto = String.valueOf(sc.nextLine());
			ps.setString(2, nombreProducto);
			
			System.out.println("Dime la cantidad del producto: ");
			int cantidad = Integer.valueOf(sc.nextLine());
			ps.setInt(4, cantidad);
			
			System.out.println("Dime el precio del producto: ");
			int precio = Integer.valueOf(sc.nextLine());
			ps.setInt(5, precio);
			
			ps.executeUpdate();
			
			System.out.println("L�nea nueva creada.");
			
			ps.close();
			
		}else {
			System.out.println("El pedido de la ID proporcionada no est� en estado 'PROCESANDO'.");
		}
		
		rs.close();
		conexion.close();
		sc.close();
		
	}
	
	
	
	/*private int id;
	private String nombre;
	private String apellidos;
	private String email;
	private String fechaNacimiento;
	private String genero;*/
	
	/*id, nombre, apellidos, email, fechaNacimiento, genero*/ //En la BBDD vienen en ese orden.
	//1,    2,      3,         4          5             6         POSICIONES DE LOS ATRIBUTOS AL USAR GETSTRING(pos)
	

}
