package dbconnect.main.java;

import java.sql.SQLException;
import java.util.Scanner;

import dbconnect.main.java.api.Connector;

public class MainApp {

		//El apartado 4 y 7 no consigo hacer que funcionen del todo. 
		//El 3, 5 y 6 funcionan, aunque se detenga el programa despu�s por una Exception.
	
		public static void main(String[] args) throws ClassNotFoundException {
			Scanner sc = new Scanner(System.in);
			
			try {

				menu();
				
				int eleccion = Integer.valueOf(sc.nextLine());

				while (eleccion != 8) {
					
					if (eleccion == 1) {
						new Connector().mostrarDatosClientes();
					}else if (eleccion == 2) {
						new Connector().mostrarPedidosPorImporteDecreciente();
					}else if (eleccion == 3) {
						new Connector().anadirCliente();
					}else if (eleccion == 4) {
						new Connector().actualizarCliente();
					}else if (eleccion == 5) {
						new Connector().eliminarCliente();
					}else if (eleccion == 6) {
						new Connector().anadirPedido();
					}else if (eleccion == 7) {
						new Connector().incluirLineasPedidoEnEstadoProcesando();
					}else {
						System.out.println("Te has equivocado seleccionando. Int�ntalo de nuevo.");
					}
					
					menu();
					eleccion = Integer.valueOf(sc.nextLine());
					
				}
				
				System.out.println("Has salido de la aplicaci�n. Adi�s.");
				
				sc.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
		public static void menu() {
			System.out.println("�Qu� es lo que quieres hacer con la BBDD 'Tienda'?\n"
					+ "------------------------------------------------\n"
					+ "1. Mostrar informaci�n sobre los clientes\n" 
					+ "2. Mostrar pedidos por importe (precio) decreciente\n"
					+ "3. A�adir cliente\n"
					+ "4. Actualizar un cliente existente (INCOMPLETO)\n"
					+ "5. Eliminar cliente\n"
					+ "6. A�adir pedido\n"
					+ "7. Incluir l�neas de pedido a un pedido existente en estado Procesando (INCOMPLETO)\n"
					+ "8. Salir");
		}
		
}
