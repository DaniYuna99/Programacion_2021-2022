package main.java.com;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MainApp {

	//Me falta poner el atributo FechaNacimiento en las List
	public static void main(String[] args) {

		List<Persona> listaPersonas = new ArrayList<Persona>();
		listaPersonas.add(new Persona("Daniel", "Carpintero", "23444444A", new LocalDate(2000, 5, 10)));
		listaPersonas.add(new Persona("Pepe", "Manchego", "23445555B"));
		listaPersonas.add(new Persona("Antonio", "Revilla", "12312312C"));
		listaPersonas.add(new Persona("José", "Jiménez","99999999D"));
		listaPersonas.add(new Persona("Manuel", "Rodríguez", "888888888E"));
		
		
		Iterator iterador = listaPersonas.iterator();
		
		while (iterador.hasNext()) {
			System.out.println(iterador.next());
		}

	}
	
	
	private static void ordenarPorNombreYApellido(List<Persona> listaPersonas) {
		listaPersonas.sort(new ComparatorPersonaNombre()
				.thenComparing(new ComparatorPersonaApellido()));
		for(Persona p: listaPersonas) {
			System.out.println(p);
		}
	}
	
	
	private static void ordenarPorApellidoYNombre(List<Persona> listaPersonas) {
		listaPersonas.sort(new ComparatorPersonaApellido()
				.thenComparing(new ComparatorPersonaNombre()));
		for(Persona p: listaPersonas) {
			System.out.println(p);
		}
	}

	
	private static void ordenarPorDniYFechaNacimiento(List<Persona> listaPersonas) {
		listaPersonas.sort(new ComparatorPersonaDni() 
				.thenComparing(new ComparatorPersonaFechaNacimiento()));
		for(Persona p: listaPersonas) {
			System.out.println(p);
		}
	}

}
