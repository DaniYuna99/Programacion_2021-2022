package main.java.com;

public class ComparatorPersonaFechaNacimiento implements Comparator<Persona>{

	public ComparatorPersonaFechaNacimiento() {
		
	}
	
	
	@Override
	public int compare(Persona p1, Persona p2) {
		return p1.getFechaNacimiento().compareTo(p2.getFechaNacimiento());
	}

}
