package main.java.com.util;

public class Aritmetica {

	public Aritmetica() {
	}
	
	public Integer sumar(Integer numero1, Integer numero2) {
		
		return numero1 + numero2;
	}
	
	public Integer restar(Integer numero1, Integer numero2) {
		
		return numero1 - numero2;
	}
}
