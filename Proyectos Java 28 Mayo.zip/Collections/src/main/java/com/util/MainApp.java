package main.java.com.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class MainApp {
	
	public static void main(String[] args) {
		
		EjemplosConjuntos.pruebaComparacionColecciones();
		
		/*Persona p1 = new Persona("Joseba", "Diaz", 20, 1.80, "Hombre");
		Persona p2 = new Persona("Andrés", "Diaz", 20, 1.80, "Hombre");
		
		System.out.println(p2.compareTo(p1));
		System.out.println(p1.compareTo(p2));

		List<Persona> listaTemporal = ColeccionUtilidades.generarListaPersonas();
		ColeccionUtilidades.ordenarListaPersonas(listaTemporal);
		System.out.println(listaTemporal);*/
	}

	public static List<Persona> generarListaPersonas() {

		Persona persona = null;
		
		List<Persona> listaPersona = new ArrayList<Persona>();
		
		listaPersona.add(persona = new Persona("Joseba", "Diaz", 20, 1.80, "Hombre"));
		listaPersona.add(persona = new Persona("Joseba", "Diaz", 20, 1.80, "Hombre"));
		listaPersona.add(persona = new Persona("Joseba", "Diaz", 20, 1.80, "Hombre"));
		listaPersona.add(persona = new Persona("Joseba", "Diaz", 20, 1.80, "Hombre"));
		listaPersona.add(persona = new Persona("Emilio", "Fernández", 20, 1.80, "Hombre"));
		
		return listaPersona;
	}
	
}
