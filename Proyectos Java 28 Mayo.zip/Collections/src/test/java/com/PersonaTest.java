package test.java.com;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import main.java.com.util.Persona;

public class PersonaTest {

	@Test
	public void test18EsMayorEdad() {
		Persona p1 = new Persona("nombre", "apellidos", 18, 1.80, "Hombre");
		//assertTrue(p1.esMayorEdad());
		//assertEquals(p1.esMayorEdad(), true);
	}
	
	@Test
	public void test17EsMenorEdad() {
		Persona p1 = new Persona("nombre", "apellidos", 17, 1.80, "Hombre");
		//assertTrue(p1.esMayorEdad());
		//assertEquals(p1.esMayorEdad(), true);
	}
	
	@Test
	public void test20EsMayorEdad() {
		Persona p1 = new Persona("nombre", "apellidos", 20, 1.80, "Hombre");
		//assertTrue(p1.esMayorEdad());
		//assertEquals(p1.esMayorEdad(), true);
	}
	
}
