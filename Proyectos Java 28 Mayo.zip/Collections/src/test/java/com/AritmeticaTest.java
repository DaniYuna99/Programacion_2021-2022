package test.java.com;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import main.java.com.util.Aritmetica;

class AritmeticaTest {

	@Test
	void testSuma1() {
		
		Aritmetica ari = new Aritmetica();
		
		assertEquals(ari.sumar(2, 2), 4);
		assertEquals(ari.sumar(0, 2), 2);
		assertEquals(ari.sumar(0, 0), 0);
		assertEquals(ari.sumar(2, 0), 2);

	}
	
	
	@Test
	public void testResta1() {
		
		Aritmetica ari = new Aritmetica();
		
		assertEquals(ari.restar(0, 2), -2);
		assertEquals(ari.restar(2, 2), 0);
		assertEquals(ari.restar(0, 0), 0);
		assertEquals(ari.restar(2, 0), 2);

	}
	
	
}
