package ejercicios;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/* Realiza una función que cifre un carácter según el cifrado César y un desplazamiento dado. */
		
		
		System.out.println("Introduce la cadena para cifrar en cifrado César: ");
		
		Scanner scanner = new Scanner (System.in);
		String cadena = String.valueOf(scanner.nextLine());
		cesar (cadena);
		
		scanner.close();

	}
	
	public static String cesar (String cadenaACifrar) {
		
		String cesar = "";
		String abecedario = "abcdefghijklmnñopqrstuvwxyz";
		
		for (int acumulador = 0; acumulador < cadenaACifrar.length() + 1; acumulador++) {
			if (abecedario.indexOf(cadenaACifrar.charAt(acumulador)) != -1) {
				cesar = String.valueOf(cadenaACifrar.charAt(acumulador));
			}
		}
		
		return cesar;
	}

}
