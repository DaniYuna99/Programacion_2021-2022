package ejercicios;

public class Ej1_Cesar {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(cifrarCesar('A', 5));

	}
	
	public static final String abecedario = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ"; 
	
	String cadena;
	
	public static char cifrarCesar (char c, int desplazamiento) {
		
		int posicion = abecedario.indexOf(c);
		int longitud = abecedario.length();
		
		int nuevaPosicion = (posicion + desplazamiento) % longitud;
		
		return abecedario.charAt(nuevaPosicion);
		
	}
}
