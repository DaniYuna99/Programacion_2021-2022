package main.java.model;

import java.time.LocalDate;
import java.util.Set;

public class Combinacion {

	private Set<Integer> numeros;
	private Set<Integer> estrellas;
	private LocalDate id;
	
	public Combinacion() {}
	
	public Combinacion(Set<Integer> numeros, Set<Integer> estrellas, LocalDate id) {
		super();
		this.numeros = numeros;
		this.estrellas = estrellas;
		this.id = id;
	}

	public Set<Integer> getNumeros() {
		return numeros;
	}

	public void setNumeros(Set<Integer> numeros) {
		this.numeros = numeros;
	}

	public Set<Integer> getEstrellas() {
		return estrellas;
	}

	public void setEstrellas(Set<Integer> estrellas) {
		this.estrellas = estrellas;
	}

	public LocalDate getId() {
		return id;
	}

	public void setId(LocalDate id) {
		this.id = id;
	}
	
	
}
