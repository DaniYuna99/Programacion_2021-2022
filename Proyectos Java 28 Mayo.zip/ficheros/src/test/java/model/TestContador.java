package test.java.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.Test;

import main.java.model.Combinacion;
import main.java.model.Historial;

class TestContador {

	@Test
	void testCalcularFrecuenciasNumeros() {
		Set<Integer> n1 = new HashSet<>();
		n1.addAll(Arrays.asList(3,6,9,15,23));
		Set<Integer> n2 = new HashSet<>();
		n2.addAll(Arrays.asList(3,6,9,25,23));
		
		Combinacion c1 = new Combinacion(n1, null, null);
		Combinacion c2 = new Combinacion(n2, null, null);
		
		List<Combinacion> registros = new ArrayList<>();
		registros.add(c1);
		registros.add(c2);
		
		Historial h = new Historial();
		Map<Integer, Integer> frecuencias = 
				h.calcularFrecuenciasNumeros(registros);
		
		
	}

}
