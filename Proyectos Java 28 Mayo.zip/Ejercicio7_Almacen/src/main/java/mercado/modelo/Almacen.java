package main.java.mercado.modelo;

public class Almacen {

	//No lo he copiado todo porque fue martes.
	
}
