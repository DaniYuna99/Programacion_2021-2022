package main.java;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) {

		escribirEnFicheroPorLineas("./archivos/archivoParaEscribir.txt");
		
	}
	
	
	public static void escribirEnFicheroPorLineas(String path) {
		String cadena;
		Scanner sc = new Scanner(System.in);

		try {
			File file = new File(path);
			FileWriter flujoEscritura = new FileWriter(file, true);
			PrintWriter filtroEscritura = new PrintWriter(flujoEscritura);
			for (int i = 1; i <= 3; i++) {
				System.out.println("Introduce texto:");
				cadena= String.valueOf(sc.nextLine());
				filtroEscritura.println(cadena);
		}
			
		filtroEscritura.close();
		flujoEscritura.close();
		sc.close();
		
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

}
