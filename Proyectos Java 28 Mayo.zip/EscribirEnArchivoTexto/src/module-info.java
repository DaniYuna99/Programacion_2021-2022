module escribirEnArchivoTexto {
}