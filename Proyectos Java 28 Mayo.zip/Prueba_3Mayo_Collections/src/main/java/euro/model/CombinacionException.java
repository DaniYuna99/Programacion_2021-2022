package main.java.euro.model;

public class CombinacionException {

}
