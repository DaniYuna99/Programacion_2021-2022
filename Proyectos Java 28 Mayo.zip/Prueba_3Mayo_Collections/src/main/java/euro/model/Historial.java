package main.java.euro.model;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class Historial {
	
	//Atributos
	public Map <LocalDate, Combinacion> sorteos;
	
	//Constructor
	public Historial () {}
	
	
	//Metodos
	public boolean addSorteo(LocalDate fecha, Combinacion combinacion) {
		
		boolean anadirSorteo = false;
		Map<LocalDate, Combinacion> mapa = new HashMap<>();
		
		if(!this.sorteos.equals(fecha) || !this.sorteos.equals(combinacion)) {
			mapa.put(fecha, combinacion);
			this.sorteos = mapa;
			anadirSorteo = true;
		}
		
		return anadirSorteo;
	}
	
	public boolean addSorteo(int dia, int meses, int anyo, Combinacion combinacion) {
		
		boolean anadirSorteo = false;
		LocalDate fecha = new LocalDate.of(anyo, meses, dia); //???
		Map<LocalDate, Combinacion> mapa = new HashMap<>();
		
		if(!this.sorteos.equals(fecha) && !this.sorteos.equals(combinacion)) {
			mapa.put(fecha, combinacion);
			this.sorteos = mapa;
			anadirSorteo = true;
		}
		
		return anadirSorteo;
	}
	
	
	public boolean actualizarSorteo(LocalDate fecha, Combinacion combinacion) {
		
		boolean actuSorteo = false;
		Map<LocalDate, Combinacion> mapa = new HashMap<>();
		
	
		if (this.sorteos.containsKey(fecha) && 
				this.sorteos.containsValue(combinacion)) {
			
		}
		
		return actuSorteo;
	}
	
	
	public boolean existeSorteo (Map<LocalDate, Combinacion> mapaRecibido) {
		
		/*Iba a refactorizar y extraer un método cuya función sea comprobar si 
		un sorteo existia, pero no sé cómo codificarlo. El método lo llamaría 
		en los métodos addSorteo y actualizarSorteo.*/
		
		if(!this.sorteos.containsKey(mapaRecibido.get(mapaRecibido))) 
			&& !this.sorteos.equals(combinacion)) {
			mapa.put(fecha, combinacion);
			this.sorteos = mapa;
			anadirSorteo = true;
		}
	}
	
	
}
