package test.main.java;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class TestHashSet {

	@Test
	void testNotContainsWhenEmpty() {
		Set<Integer> vacio = new HashSet<>();
		
		assert(!vacio.contains(3));
	}
	
	@Test
	void testContainsElement() {
		Set<Integer> relleno = new HashSet<>();
		relleno.add(3);
		relleno.add(5);
		
		assert(!relleno.contains(30));
	}
	
	@ValueSource(ints = {1,2,3,4})
	@ParameterizedTest
	void testSize() {
		Set<Integer> relleno = new HashSet<>();
		relleno.add(3);
		relleno.add(5);
		relleno.add(3);
		relleno.add(5);
		relleno.add(3);
		relleno.add(5);
		
		assertEquals(relleno.size(), 2);
	}
	
	@Test
	void testSizeEmpty() {
		Set<Integer> relleno = new HashSet<>();
		assertEquals(relleno.size(), 0);
	}
	
	@Test
	void testIsEmpty() {
		Set<Integer> relleno = new HashSet<>();
		assertTrue(relleno.isEmpty());
		assertEquals(relleno.isEmpty(), true);
	}
	
	
	@Test
	void testIsNotEmpty() {
		Set<Integer> relleno = new HashSet<>();
		relleno.add(2);
		relleno.add(3);
		relleno.add(4);
		assertFalse(relleno.isEmpty());
		assertEquals(relleno.isEmpty(), false);
	}
	
	
	@Test
	void testAdd() {
		Set<Integer> relleno = new HashSet<>();
		assertEquals(relleno.isEmpty(), true);
		relleno.add(2);
		assertEquals(relleno.isEmpty(), false);

	}
	
	
	@Test
	void testRemove() {
		Set<Integer> relleno = new HashSet<>();
		relleno.add(2);
		assertEquals(relleno.isEmpty(), false);
		relleno.remove(2);
		assertEquals(relleno.isEmpty(), true);
	}
	
	//@Test
	void testClone() {
		Set<Integer> relleno = new HashSet<>();
		relleno.add(2);
		relleno.add(3);
		relleno.add(4);
		Set<Integer> rellenoClon = new HashSet<>();
		//rellenoClon = relleno.clone();
	}
	
}
