package main.java;

public enum Genero {
	HOMBRE, MUJER, NOBINARIO;
}
