package main.java;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) throws Exception {
		
		//practicaDeHaceTiempo();
		
		/*Scanner sc = new Scanner(System.in);
		System.out.println("Dime tu g�nero:");
		String respuesta = String.valueOf(sc.nextLine().toUpperCase());
		Genero genero = Genero.valueOf(respuesta);
		
		introducirGenero(genero);*/
			
		/*Collection<String> coleccion = new ArrayList<>();
		coleccion.add("Ryo");
		coleccion.add("Robert");
		coleccion.add("Yuri");
		coleccion.add("Takuma");
		
		Iterator<String> iterador = coleccion.iterator();
		
		System.out.println(coleccion.toString());*/
		
		/*List<String> lista = new ArrayList<>();
		lista.add("Ryo");
		lista.add("Robert");
		lista.add("Yuri");
		lista.add("Takuma");
		
		//Iterator<String> iterador = lista.iterator();
		
		for (String nombre : lista) {
			if (nombre.equals("Takuma")) {
				lista.set(lista.indexOf(nombre), "Mr.Karate");
			}
		}
		
		//Comparator<String> comparator = Comparator.naturalOrder();
		
		lista.sort(new ComparatorString());
		System.out.println(lista.toString());*/
		
		
		
		/*for (String nombre : coleccion) {
			if (nombre.startsWith("R")) {
				System.out.println(nombre);
			}
		}*/
		
		
		/*Collection<Integer> numeros = new HashSet<>();
		numeros.add(1);
		numeros.add(3);
		numeros.add(2);
		numeros.add(4);
		
		Integer resultado = 0;
		
		for (Integer numero : numeros) {
			if (numero > 2) {
				resultado += numero;
			}
		}
		
		System.out.println(resultado);*/

 
		/*Map<String, String> mapa = new HashMap<>();
		mapa.put("Heihachi", "Mishima");
		mapa.put("Kazuya", "Mishima");
		mapa.put("Jin", "Kazama");
		mapa.put("Lee", "Chaolan");
		mapa.put("Otoma", "Raga");
		
		if (mapa.get("Heihachi").equals("Mishima")) {
			mapa.remove("Heihachi");
		}
		
		if (mapa.containsKey("Lee")) {
			System.out.println("Excerent!");
		}
		
		if(mapa.keySet().contains("Jin")) {
			System.out.println("This is reality.");
		}
		
		if(mapa.values().contains("Kazama")) {
			mapa.("Mishima");
		}
		
		System.out.println(mapa.toString());*/
		
		
		File file = new File("./archivos/Texto.txt");
		
		/*if (file.exists()) {
			file.delete();
		}
		
		if (!file.exists()) {
			file.createNewFile();
		}*/
		
		System.out.println(file.exists());
		
		
		try {
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			String linea = br.readLine();
			String ej = "";
			while (linea != null) {
				System.out.println(linea);
				linea = br.readLine();
				if (linea.contains("Daniel")) {
					ej = "Daniel";
				}
				
				
			
			}
			
			System.out.println(ej);
			
			fr.close();
			br.close();
		
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (NullPointerException e) {
			System.out.println(e.getMessage());
		}
		
		
		
		
	}		
			
	

	public static void introducirGenero(Genero genero) {
		
		if (genero.equals(Genero.HOMBRE)) {
			System.out.println("Eres un hombre, comprendido.");
				
		}else if (genero.equals(Genero.MUJER)) {
			System.out.println("Eres una mujer, de acuerdo.");
		
		}else if (genero.equals(Genero.NOBINARIO)) {
			System.out.println("Deja de hacer el payaso, anda.");
				
		}
		
			
	}

	
	public static void practicaDeHaceTiempo() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Pon tu nombre, y te saludar�:");
		String nombre = String.valueOf(sc.nextLine());
		LocalTime hora = LocalTime.now().minusHours(1);
		LocalDate diaDeHoy = LocalDate.now();
		System.out.println("Hola " + nombre + ". Encantado de conocerlo.");
		System.out.print("Son las:\n");
		System.out.println(hora + " ahora mismo.");
		System.out.println("Y es el d�a: " + diaDeHoy + ".");
		LocalDate dia = LocalDate.parse("2000-10-20");
		DayOfWeek dia2 = dia.getDayOfWeek();
		System.out.println(dia2);
	}

}
