package file;

import java.io.File;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class Metadata {
	
	private boolean esDirectorio;
	private boolean esFichero;
	private LocalDateTime date;
	private boolean lectura;
	private boolean escritura;
	private boolean ejecucion;
	private String contenido;
	

	public Metadata(String path) {
		
		File archivo = new File(path);
		
		if (archivo.exists()) {
			date = LocalDateTime.ofInstant(new Date(archivo.lastModified()).toInstant(), ZoneId.systemDefault());
		
			this.esDirectorio = archivo.isDirectory();
			this.esFichero = archivo.isFile();
			this.date = date;
			this.lectura = archivo.canRead();
			this.escritura = archivo.canWrite();
			this.ejecucion = archivo.canExecute();
			//this.contenido = archivo.
					
		}
		
		
	}


	@Override
	public String toString() {
		return "Metadata:\n" 
				+ "Es directorio: " + this.esDirectorio + "/n"
				+ "Es fichero: " + this.esFichero + "/n"
				+ "Última fecha de modificación: " + this.date + "/n"
				+ "Permiso de lectura: " + this.lectura + "/n"
				+ "Permiso de escritura: " + this.escritura + "/n"
				+ "Permiso de ejecución: " + this.ejecucion + "/n"
				+ "Contenido: " + this.contenido + "/n";
	}
	
	
}
