module geo_lecturaEscrituraFicheros {
}