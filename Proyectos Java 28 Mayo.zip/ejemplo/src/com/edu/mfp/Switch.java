package com.edu.mfp;

import java.util.Scanner;

public class Switch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.out.println("¿Qué día de la semana es?");
		int dia;
		Scanner scanner = new Scanner (System.in); scanner.close();
		dia = Integer.valueOf(scanner.next());
		
		switch (dia) {
			case 1: {
				System.out.println("Lunes");
				break;
			}case 2: {
				System.out.println("Martes");
				break;
			}case 3: {
				System.out.println("Miércoles");
				break;
			}case 4: {
				System.out.println("Jueves");
				break;
			}case 5: {
				System.out.println("Viernes");
				break;
			}case 6: {
				System.out.println("Sábado");
				break;
			}case 7: {
				System.out.println("Domingo");
				break;
			}default:
				System.out.println("El día introducido no es válido.");
			}

	}

}
