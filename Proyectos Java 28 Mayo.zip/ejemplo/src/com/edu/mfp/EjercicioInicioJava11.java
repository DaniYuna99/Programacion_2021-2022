package com.edu.mfp;

import java.util.Scanner;

public class EjercicioInicioJava11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//11. Muestra los números del 100 al 1 utilizando la instrucción while
		
		System.out.println("Programa para contar a la inversa desde el número que se indique.");
		System.out.println("Indica el número.");
		Scanner scanner = new Scanner (System.in);
		int comienzo2 = Integer.valueOf (scanner.next());
		
		whileHastaElComienzo(comienzo2);
		
		scanner.close();

	}
	
	public static void whileHastaElComienzo(int comienzo) {
		
		while (comienzo > 0) {
			System.out.println(comienzo);
			comienzo--;
		}
	}

}
