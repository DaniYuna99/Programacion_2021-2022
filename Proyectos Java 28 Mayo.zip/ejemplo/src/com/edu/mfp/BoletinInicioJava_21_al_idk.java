package com.edu.mfp;

import java.util.Scanner;

public class BoletinInicioJava_21_al_idk {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/* 21. Realiza un programa que sume los 100 números siguientes a un número entero y positivo
		introducido por teclado. Se debe comprobar que el dato introducido es correcto (que es un
		número positivo). */
		
			//System.out.println(Ejercicio21());
			
		//===========================================================
		//===========================================================
			
		/* 42. Realizar un método que dada una cadena de entrada, comprueba si es una contraseña
		FUERTE o DÉBIL. Se considera que una contraseña es fuerte si contiene 8 o más
		caracteres, y entre ellos al menos hay una mayúscula, una minúscula, un signo de
		puntuación y un dígito.	*/
		
			/* System.out.println(Ejercicio42("debil"));
			System.out.println(Ejercicio42("Hermenegildo.8"));
			System.out.println(Ejercicio42("Her.8"));
			System.out.println(Ejercicio42(".9**aAAA")); */
		
		//===========================================================
		//===========================================================
			
			
		/* 43. Elabora un programa que codifique una cadena, de tal modo que en el resultado se inviertan
		cada 2 caracteres. Los caracteres intercambiados no pueden volver a intercambiarse.
		Ejemplo:
		Entrada -> Hola mundo
		Salida -> oHalm nuod */
		
			/* System.out.println(Ejercicio43("Cadena")); //aCedan
			System.out.println(Ejercicio43("Cadenas")); //aCedans
			
			Scanner sc = new Scanner(System.in);
			System.out.println(Ejercicio43(sc.nextLine()));
			sc.close(); */

		
		/* BOLETÍN 2 JAVA: Ejercicio 2:
			Los números romanos son un sistema numérico posicional que a cada símbolo le corresponde un
				valor. Así:
				● I equivale a 1, II es igual a 2, III es igual a 3
				● V es igual a 5
				● X es igual a 10
				● L es igual a 50
				● C es igual a 100
				● D es igual a 500
				● M es igual a 1000
				→ Si un símbolo de valor inferior a otro se coloca antes, su valor se resta al siguiente. Así:
				IC ⇒ 99
				MCM ⇒ 1900
				MDCLXI ⇒ 1661
				- Elabora un programa que solicite por teclado un número romano y devuelva su equivalente
				en decimal.
				- Elabora un programa complementario que dado un número decimal, obtenga su equivalente
				en romano
				* Para simplificar el problema obvia la regla que resta el valor. */
		
			System.out.println(Boletin2Ej1("DCI")); //601
			System.out.println(Boletin2Ej1(""));
		
	}
	
	public static int Ejercicio21 () {
		
		int sumatoria = 0;
		int acumulador = 1;
		
		System.out.println("Ejercicio 21: Programa que suma 100 números, y devuelve -1 si uno de los números es negativo.");
		
		while (acumulador <= 10) {
			System.out.println("Introduce un número: ");
			Scanner scanner = new Scanner (System.in);
			int numNuevo = Integer.valueOf(scanner.next());
			
			if (numNuevo < 0) {
				sumatoria = -1;
				scanner.close();
				return sumatoria;
			}
			
			sumatoria = sumatoria + numNuevo;
			acumulador++;
			
		}	
		
		return sumatoria;
		
	}
	
	public static String Ejercicio42 (String password) {
		
		String resultado = "Débil";
		
		boolean existeMayuscula = false;
		boolean existeMinuscula = false;
		boolean existeDigito = false;
		boolean existeSimboloPuntuacion = false;
		
		String simbolosPuntuacion = ".,;:?¿¡!";
		
		if (password.length() >= 8) {
			for (int i=0; i<password.length(); i++) {
				if (Character.isUpperCase(password.charAt(i))) {
					existeMayuscula = true;
				}else if (Character.isLowerCase(password.charAt(i))) {
					existeMinuscula = true;
				}else if (Character.isDigit(password.charAt(i))) {
					existeDigito = true;
				}else if (simbolosPuntuacion.indexOf(password.charAt(i)) != -1) {
					existeSimboloPuntuacion = true;
				}
			}
			
			if (existeMayuscula && existeMinuscula && existeDigito && existeSimboloPuntuacion) {
				resultado = "Fuerte";
			}
			
		}
		
		return resultado;

	}
	
	public static String Ejercicio43 (String cadOriginal) {
		
		String cadenaCodificada = " ";
		
		for(int i=1; i<cadOriginal.length(); i+=2) {
			cadenaCodificada = cadenaCodificada + cadOriginal.charAt(i) + cadOriginal.charAt(i-1);
		}
		
		if (cadOriginal.length() % 2 != 0) {
			cadenaCodificada += cadOriginal.substring(cadOriginal.length() - 1);
		}
		
		return cadenaCodificada;
		
		
	}
	
	public static int Boletin2Ej1 (String nRomano) {
		
		int resultado = 0;
		
		for (int i=0; i < nRomano.length(); i++) {
			
			switch (nRomano.charAt(i)) {
				case 'M':
					resultado += 1000;
					break;
				case 'D':
					resultado += 500;
					break;
				case 'C':
					resultado += 100;
					break;
				case 'L':
					resultado += 50;
					break;
				case 'X':
					resultado += 10;
					break;
				case 'V':
					resultado += 5;
					break;
				case 'I':
					resultado += 1;
					break;
				default:
					break;
			}
		}
		return resultado;
	}
	
	public static final int D = 500;
	
	public static String Boletin2Ej1_DecimalARomano (int nDecimal) {
		
		String nRomano = "";
		
		int nQuinientos = nDecimal / D;
		
		if (nDecimal % D != 0) {
			int resto = nDecimal % D;
		}
	}
	
}
