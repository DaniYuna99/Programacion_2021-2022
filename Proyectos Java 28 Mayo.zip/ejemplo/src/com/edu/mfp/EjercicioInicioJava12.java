package com.edu.mfp;

import java.util.Scanner;

public class EjercicioInicioJava12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//12. Método que muestre los números del 100 al 1 utilizando la instrucción do..while
		
		System.out.println("Programa que muestra los números entre el que indique hasta el 1, a la inversa.");
		System.out.println("Indique el número:");
	
		Scanner scanner = new Scanner (System.in);
		int comienzo2 = Integer.valueOf(scanner.next());
		
		cuentaAtrasConBucleWhile(comienzo2);
		
		scanner.close();
	
	}
		
		public static void cuentaAtrasConBucleWhile(int comienzo) {
			
			while (comienzo > 0) {
				System.out.println(comienzo);
				comienzo--;
			}
		}
}
