package com.edu.mfp;

import java.util.Scanner;

public class EjercicioInicioJava2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/* 2. Escribe un método que reciba por parámetro el día de 
		 * la semana (Lunes, Martes, Miércoles, etc) y devuelva 
		 * qué asignatura toca a primera hora ese día.
		*/
		
		System.out.println("Introduce el día de la semana y te diré qué es lo que toca a primera hora:");
		Scanner scanner = new Scanner (System.in);
		int dia = Integer.valueOf (scanner.next());
		
		switch (dia) {
		
			case 1:
				System.out.println(dia);
				System.out.println("Toca a primera Sistemas Informáticos.");
				break;
			
			case 2:
				System.out.println(dia);
				System.out.println("Toca a primera Programación.");
				break;
	
			case 3,4,5:
				System.out.println(dia);
				System.out.println("Toca a primera Bases de Datos.");
				break;
			
			default:
				System.out.println("El número introducido está fuera de rango. Introduce del 1 al 5.");
		}	
	
			
		scanner.close();
		
	}

}
