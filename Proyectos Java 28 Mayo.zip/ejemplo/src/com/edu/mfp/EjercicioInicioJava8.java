package com.edu.mfp;

import java.util.Scanner;

public class EjercicioInicioJava8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//8. Muestra los números del 1 al 100 utilizando la instrucción while (mientras)
		
		System.out.println("Programa que cuenta hasta un número usando un bucle While.");
		System.out.println("Introduce el número para que el programa cuente hasta él:");
		Scanner scanner = new Scanner (System.in);
		int limite = Integer.valueOf(scanner.next());
		
		whileHastaelLimite(limite);
		
		scanner.close();

	}
	
	public static void whileHastaelLimite(int limit) {
		
		int acumulador = 1;
		
		while (acumulador < limit + 1) {
			System.out.println(acumulador);
			acumulador++;
		}
	}

}
