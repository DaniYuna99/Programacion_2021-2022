//1. Paquete donde está ubicado (OBLIGATORIO, SIEMPRE EN LA 1º LÍNEA)
package com.edu.mfp;

//2. Importamos librerías (OPCIONAL, SÓLO SI SE USAN LIBRERÍAS)
// Para importar una librería que falta (por ejemplo, Scanner), pulsar Control + Shift + O(la letra o del teclado)
import java.util.Scanner;

//3. Nombre de la clase (OBLIGATORIO)
public class AyudaParaProyectosJava {
	
	//4. Atributos y métodos
	
	// Punto de entrada - método main 
	public static void main(String[] args) {
		Scanner scanner = new Scanner (System.in); scanner.close();
		System.out.println("Hello");
	}

}
