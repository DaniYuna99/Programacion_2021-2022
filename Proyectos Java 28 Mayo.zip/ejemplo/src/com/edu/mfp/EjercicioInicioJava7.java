package com.edu.mfp;

public class EjercicioInicioJava7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//7. Método que muestre los números del 1 al 100 utilizando la instrucción for (para)
		
		//NOTA: Si te dice el ejercicio "muestre" quiere decir mostrarlo en consola.
		
		contador(1000);

	}
	
	public static void contador(int limiteSuperior) {
		
		for (int i=1; i<=limiteSuperior; i++) {
			System.out.println(i);
		}

	}

}