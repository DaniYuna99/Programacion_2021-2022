package com.edu.mfp;

import java.util.Scanner;

public class EjercicioInicioJava10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//10. Escribe los números del 100 al 1 utilizando la instrucción for
		
		System.out.println("Programa para contar desde el número que se indique hasta el 1.");
		System.out.println("Indica el número:");
		Scanner scanner = new Scanner (System.in);
		int comienzo2 = Integer.valueOf(scanner.next());
		
		forDesdeComienzoHasta1(comienzo2);
		
		scanner.close();
		
	}
	
	public static void forDesdeComienzoHasta1 (int comienzo2) {
		for (int i = 100; i > 0; i--) {
			System.out.println(i);
		}
	}

}
