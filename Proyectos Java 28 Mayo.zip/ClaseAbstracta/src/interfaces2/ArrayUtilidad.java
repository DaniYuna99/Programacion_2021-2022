package interfaces2;

public class ArrayUtilidad {

	public static void imprimirArray(Object[] lista) {
		
		for(int i = 0; i < lista.length; i++) {
			System.out.println(lista[i]);
		}
		
		/*for(Object elemento : lista) {
			System.out.println(elemento);
		}*/
	}
}
