package com.jacaranda.notas;

public interface Activable {

	public void activar();
		
	public void desactivar();
	
}
