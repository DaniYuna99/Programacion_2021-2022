package com.jacaranda.notas;

import java.time.LocalDateTime;
import java.util.Objects;

import com.jacaranda.bloc.Bloc;


public class Nota implements Comparable<Nota> {

	
	//Atributos
	private static int codigoSiguiente;
	private int codigo;
	private String texto;
	private LocalDateTime fechaCreacion;
	private LocalDateTime fechaUltimaModificacion;
		
		
		
	//Constructores
	public Nota(String texto) {
		this.texto = texto;
		this.codigo = codigoSiguiente++;
		this.fechaCreacion = LocalDateTime.now();
	}



	//Metodos
	public boolean isModificado() {
		return this.fechaUltimaModificacion != null;
	}
		
	
	public boolean isEmpty() {
		return this.texto == null || this.texto.isBlank();
	}
	
	
	public boolean isCreadoAnterior (Nota otraNota) {
		return this.getFechaCreacion().isBefore(otraNota.getFechaCreacion());
	}
	
	
	public boolean isModificadoAnterior(Nota otraNota) {
		
		boolean esAnterior = false;
		
		if(this.getFechaUltimaModificacion() == null && otraNota.getFechaUltimaModificacion()==null) {
			esAnterior = false;
		
		}else if(this.isModificado() && otraNota.isModificado()) {
			esAnterior = this.getFechaUltimaModificacion().isBefore(otraNota.getFechaUltimaModificacion());
		
		}else if (this.isModificado()){
			esAnterior = true;
		}
		
		return esAnterior;
	}	
		
		
	
	//Getters-Setters
	public int getCodigo() {
		return codigo;
	}


	public String getTexto() {
		return texto;
	}


	public void setTexto(String texto) {
		this.texto = texto;
	}


	public LocalDateTime getFechaCreacion() {
		return fechaCreacion;
	}


	public LocalDateTime getFechaUltimaModificacion() {
		return fechaUltimaModificacion;
	}

	
	
	
	@Override
	public int compareTo(Nota otraNota) {
		int result = 0;
		if (otraNota != null && this.getTexto() != null && otraNota.getTexto() != null) {
			return this.getTexto().compareTo(otraNota.getTexto());
		}
		
		return result;
	}




	@Override
	public int hashCode() {
		return Objects.hash(codigo, fechaCreacion, fechaUltimaModificacion, texto);
	}


	@Override
	public boolean equals(Object obj) {
		
		boolean sonIguales = true;
		
		if(obj != null) {
			if(this == obj) {
				sonIguales = true;
			}else {
				Nota laOtra = (Nota)obj;
				sonIguales = this.texto.equals(laOtra.getTexto())
							&& this.getFechaCreacion().equals(laOtra.getFechaCreacion());
			}
		}
		
		return sonIguales;
	}



	@Override
	public String toString() {
		return "Nota [texto=" + texto + "]";
	}
	
	
	
}
