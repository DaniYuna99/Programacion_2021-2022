package com.jacaranda.bloc;

public class BlocException extends RuntimeException {

	public static final String MENSAJE = "Se ha producido una excepción.";
	
	public BlocException() {
		super();
	}

	public BlocException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public BlocException(String message, Throwable cause) {
		super(message, cause);
	}

	public BlocException(String message) {
		super(message);
	}

	public BlocException(Throwable cause) {
		super(cause);
	}

	
}
