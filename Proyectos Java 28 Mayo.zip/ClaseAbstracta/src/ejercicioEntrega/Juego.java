package ejercicioEntrega;

public abstract class Juego {

	public abstract Integer getContinues();
	
	public abstract Integer getMuertes();
}
