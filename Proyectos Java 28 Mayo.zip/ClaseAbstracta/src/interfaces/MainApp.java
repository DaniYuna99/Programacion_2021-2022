package interfaces;

import java.util.Arrays;

import interfaces2.ArrayUtilidad;

public class MainApp {

	public static void main(String[] args) {

		Entero[] enteros = new Entero[5];
		
		Entero e1 = new Entero(3);
		Entero e2 = new Entero(0);
		Entero e3 = new Entero(17);
		Entero e4 = new Entero(6);
		Entero e5 = new Entero(62);

		
		enteros[0] = e1;
		enteros[1] = e2;
		enteros[2] = e3;
		enteros[3] = e4;
		enteros[4] = e5;
		
		Comparable[] lista = new Comparable[3];
		lista[0] = (Comparable) e2;
		lista[1] = (Comparable) e3;
		lista[2] = (Comparable) e1;
		
		Arrays.sort(enteros);
		
		String[] nombres = new String[5];
		nombres[0] = new String("Vicente");
		nombres[1] = new String("Joseba");
		nombres[2] = new String("Luque");
		nombres[3] = new String("Felipe");
		nombres[4] = new String("Daniel");
		
		Arrays.sort(nombres);

	
		ArrayUtilidad.imprimirArray(nombres);
		ArrayUtilidad.imprimirArray(enteros);
	}

}
