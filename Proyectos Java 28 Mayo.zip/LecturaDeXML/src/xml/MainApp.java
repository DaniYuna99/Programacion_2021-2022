package xml;

import java.util.ArrayList;
import java.util.List;

import xml.model.CasetaFeria;
import xml.model.Coche;
import xml.reader.XMLReader_Coche;
import xml.writer.XMLWriter;

public class MainApp {

	public static void main(String[] args) {
		
		XMLReader_Coche reader = new XMLReader_Coche();
		List<Coche> coches = reader.cargarArchivoDatos("./files/coches.xml");
		List<CasetaFeria> casetas = reader.cargarArchivoDatos("./files/casetasferia.xml");
		for(CasetaFeria caseta : casetas) {
			System.out.println(caseta);
		}
		System.out.println("");
		
		List<CasetaFeria> casetasNuevas = new ArrayList<>();

		CasetaFeria c1 = new CasetaFeria("Jacarandá", "Rafael Gómez Orteda", 15, 2, 1, 12, Clase.MUNICIPAL, "");
		CasetaFeria c2 = new CasetaFeria("Brenes", "Rafael Gómez Orteda", 15, 3, 1, 12, Clase.MUNICIPAL, "");
		CasetaFeria c3 = new CasetaFeria("Los Amigos", "Rafael Gómez Orteda", 15, 2, 1, 12, Clase.MUNICIPAL, "");
		casetasNuevas.add(c1);
		casetasNuevas.add(c2);
		casetasNuevas.add(c3);
		
		XMLWriter writer = new XMLWriter();
		writer.crearArchivoDatosXML(casetas, "./files/nuevascasetas.xml");

		
		//XMLReader_Coche reader = new XMLReader_Coche();
		//reader.cargarArchivoDatos("./files/coches.xml");
		
		//XMLReader_CasetasFeria reader2 = new XMLReader_CasetasFeria();
		//reader2.cargarArchivoDatos("./files/casetasferia.xml");
		
		
		//File file = new File ("./files/casetasferia.xml");
		//System.out.println(file.exists());
	}

}
