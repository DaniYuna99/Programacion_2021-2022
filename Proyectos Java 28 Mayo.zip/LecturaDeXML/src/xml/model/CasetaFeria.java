package xml.model;

public class CasetaFeria {
	
	private String titulo;
	private String calle;
	private Integer numero;
	private Integer modulos;
	private String clase;
	private Integer id;
	private Integer idCalle;
	
	
	public CasetaFeria(String titulo, String calle, Integer numero, 
			Integer modulos, String clase, Integer id, Integer idCalle) {
		super();
		this.titulo = titulo;
		this.calle = calle;
		this.numero = numero;
		this.modulos = modulos;
		this.clase = clase;
		this.id = id;
		this.idCalle = idCalle;
	}


	public String getTitulo() {
		return titulo;
	}


	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}


	public String getCalle() {
		return calle;
	}


	public void setCalle(String calle) {
		this.calle = calle;
	}


	public Integer getNumero() {
		return numero;
	}


	public void setNumero(Integer numero) {
		this.numero = numero;
	}


	public Integer getModulos() {
		return modulos;
	}


	public void setModulos(Integer modulos) {
		this.modulos = modulos;
	}


	public String getClase() {
		return clase;
	}


	public void setClase(String clase) {
		this.clase = clase;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public Integer getId_calle() {
		return idCalle;
	}


	public void setId_calle(Integer id_calle) {
		this.idCalle = id_calle;
	}
	
}
