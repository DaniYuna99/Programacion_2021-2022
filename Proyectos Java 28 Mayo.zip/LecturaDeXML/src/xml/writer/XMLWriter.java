package xml.writer;

import java.io.File;
import java.util.Collection;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import xml.model.CasetaFeria;

public class XMLWriter {
	
	/**
	 * Crea un XML con los datos de la colección pasada como 
	 * primer argumento en la ruta especificada.
	 * @param casetas coleccion de datos
	 * @param path ruta de creación del archivo
	 */
	public void crearArchivoDatosXML(Collection<CasetaFeria> casetas, String path) {
		
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newDefaultInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.newDocument();
			
			Element raiz = document.createElement("casetas");
			document.appendChild(raiz);
			
			for (CasetaFeria caseta : casetas) {
				Element elementoCaseta = document.createElement("caseta");
				raiz.appendChild(elementoCaseta);
				
				//Añado atributo a la caseta
				Attr atributo = document.createAttribute("id");
				atributo.setValue(caseta.getId().toString());
				elementoCaseta.setAttributeNode(atributo);
				
				//Añado un elemento <nombre/> a la caseta
				Element nombre = document.createElement("nombre");
				Node textoTitulo = document.createTextNode(caseta.getTitulo());
				nombre.appendChild(textoTitulo);
				elementoCaseta.appendChild(nombre);
			}
			
			TransformerFactory tfactory = TransformerFactory.newDefaultInstance();
			Transformer transformer = tfactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			
			DOMSource source = new DOMSource(document);
			StreamResult result = new StreamResult(new File(path));
			
			transformer.transform(source, result);
			
			
		}catch (ParserConfigurationException | TransformerException e) {
			e.printStackTrace();
		}
		
	}
}
