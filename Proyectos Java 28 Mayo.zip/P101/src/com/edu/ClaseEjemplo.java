package com.edu;

public class ClaseEjemplo {
	
	String putamadre = "No me reconoce el syso.";

}
