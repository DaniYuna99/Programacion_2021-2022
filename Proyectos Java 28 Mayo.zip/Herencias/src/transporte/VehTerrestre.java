package transporte;

public class VehTerrestre extends Vehiculo {

	private int numRuedas = 0;
	
	public VehTerrestre() {}
	
	public VehTerrestre(int ruedas, String motor) {
		super(motor);
		this.numRuedas = ruedas;
		
	}
	
	
	public String toString() {
		return super.toString()+ " con " + numRuedas + " ruedas";
	}

	
	//Getters-Setters
	public int getNumRuedas() {
		return numRuedas;
	}

	public void setNumRuedas(int numRuedas) {
		this.numRuedas = numRuedas;
	}
}
