package transporte;

public class Coche extends VehTerrestre {

	public Coche () {
		setMotor("diesel");
		setNumRuedas(4);
	}
}
