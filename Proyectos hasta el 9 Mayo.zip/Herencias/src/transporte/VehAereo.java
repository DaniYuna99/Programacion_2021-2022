package transporte;

public class VehAereo extends Vehiculo{

	//Atributos
	private Double combustible;
	private Integer numAlas;
	
	//Constructores
	public VehAereo () {}
	
	public VehAereo (double combustible, String motor) {
		super(motor);
		this.combustible = combustible;
		
	}
	
	
	
	
	//Getters-Setters
	public double getCombustible() {
		return combustible;
	}

	public void setCombustible(double combustible) {
		this.combustible = combustible;
	}

	public Integer getNumAlas() {
		return numAlas;
	}

	public void setNumAlas(Integer numAlas) {
		this.numAlas = numAlas;
	}
	
	

}
