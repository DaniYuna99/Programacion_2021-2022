package transporte;

import java.util.Scanner;

public class GestionVehiculosApp {

	public static void main(String[] args) {
		
		/*VehTerrestre[] garaje = new VehTerrestre[10];
		
		Coche ferrari = new Coche();
		Coche panda = new Coche();
		Moto kawasaki = new Moto();
		Moto dingo = new Moto();
		
		garaje[0] = ferrari;
		garaje[1] = panda;
		garaje[2] = kawasaki;
		garaje[3] = dingo;*/
	}
	
	public static void menu() {
		
		Vehiculo[] almacen;
		
		System.out.println("¿Qué tipo de almacén de vehículos quiere?"
				+ " \n (1: Garaje, 2: Hangar, 3: Puerto)");
		
		Scanner sc = new Scanner(System.in);
		
		int opcTipoAlmacen = Integer.valueOf(sc.nextLine());
		
		if (opcTipoAlmacen == 1) {
			almacen = new VehTerrestre[10];
		}else if (opcTipoAlmacen == 2) {
			almacen = new VehAereo[5];
		}else {
			almacen = new VehMaritimo[20];
		}
		
		almacen[0] = new Coche();
		
		
		sc.close();
	}
}
