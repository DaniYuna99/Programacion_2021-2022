package transporte;

import java.util.Objects;

public class Vehiculo {
	
	//Atributos
	private String motor;
	
	
	//Constructores
	public Vehiculo () {}
	
	public Vehiculo (String motor) {
		this.motor = motor;
	}
	
	
	//Metodos
	public void moverse() {
		System.out.println("Me estoy desplazando.");
	}
	
	public void pararse() {
		System.out.println("Estoy parado.");
	}

	
	
	//Getters-Setters
	public String getMotor() {
		return motor;
	}

	public void setMotor(String motor) {
		this.motor = motor;
	}

	
	//toString()
	@Override
	public String toString() {
		return "Vehiculo con motor = " + motor;
	}

	
	//hash y equals
	@Override
	public int hashCode() {
		return Objects.hash(motor);
	}

	@Override
	public boolean equals(Object obj) {
		
		boolean sonIguales = false;
		
		if (this == obj) {
			sonIguales = true;
			
		}else {
			Vehiculo other = (Vehiculo) obj;
			sonIguales = this.getMotor().equals(other.getMotor());
		}
		
		return sonIguales;
	}
	
	
	
	
	
	
	
	
	
}
