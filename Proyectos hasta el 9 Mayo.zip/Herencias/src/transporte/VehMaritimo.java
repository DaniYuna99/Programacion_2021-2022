package transporte;

public class VehMaritimo extends Vehiculo {

}
