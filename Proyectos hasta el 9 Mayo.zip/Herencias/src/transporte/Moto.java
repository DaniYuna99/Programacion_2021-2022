package transporte;

public class Moto extends VehTerrestre {

	public Moto() {
		super(2, "gasolina");
		setMotor("gasolina");
		setNumRuedas(2);
	}
}
