package transporte;

public class Avion extends VehAereo{

	public Avion () {
		setCombustible(100.0);
		setNumAlas(2);
	}
	
}
