package transporte;

public class Dron extends VehAereo{

}
