package main.java.ficheros;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import main.java.model.Combinacion;

public class MainApp {

	public static void main(String[] args) {
		
		cargarHistorico("./files/Euromillones - 2004 a 2022.csv");
		
	}
	
	/*Comprobar el número y estrella que más se repite, 
	 * y el que menos.*/
	//public static void calcular

	public static List<Combinacion> cargarHistorico(String rutaFichero) {
		
		List<Combinacion> historial = new ArrayList<>();

		try {
			
			File file = new File(rutaFichero);
			
			FileReader fr = new FileReader(file);			
			
			BufferedReader br = new BufferedReader(fr);
			br.readLine();
			String linea = br.readLine();

			while (linea != null) {
				
				System.out.println(linea);

				String[] info = linea.split(",");
				Set<Integer> numeros = new HashSet<>();
				numeros.add(Integer.valueOf(info[1]));
				numeros.add(Integer.valueOf(info[2]));
				numeros.add(Integer.valueOf(info[3]));
				numeros.add(Integer.valueOf(info[4]));
				numeros.add(Integer.valueOf(info[5]));

				Set<Integer> estrellas = new HashSet<>();
				estrellas.add(Integer.valueOf(info[7]));
				estrellas.add(Integer.valueOf(info[8]));
				
				Combinacion combinacion = new Combinacion(numeros, estrellas, null);
				historial.add(combinacion);
				
				linea = br.readLine();
				
			}
			
			br.close();
			fr.close();
			
			System.out.println(historial);
			
		}catch (IOException io) {
			System.out.println(io.getMessage());
		}
		
		return historial;
	}
	
}
