package main.java.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Historial {

	List<Combinacion> registros;
	
	public Historial() {
		registros = new ArrayList<>();
	}
	
	public Map<Integer, Integer> 
		calcularFrecuenciasNumeros(List<Combinacion> reg) {
		Map<Integer, Integer> freq = new HashMap<>();
		
		for(Combinacion c : reg) {
			for(Integer i : c.getNumeros()) {
				if(!freq.containsKey(i)) {
					
				}
			}
		}
		
		return null;
	}
}
