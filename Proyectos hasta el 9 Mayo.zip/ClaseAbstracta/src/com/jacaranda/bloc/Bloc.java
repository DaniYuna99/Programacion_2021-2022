package com.jacaranda.bloc;

import java.util.Arrays;
import java.util.Objects;

import com.jacaranda.notas.Activable;
import com.jacaranda.notas.Nota;
import com.jacaranda.notas.NotaAlarma;
import com.jacaranda.notas.NotaAlarmaException;

public class Bloc {

	//Atributos
		private static final int NUMERO_NOTAS_MAXIMA = 50;
		private int numNotas = 0;
		private String nombre;
		
		private Nota[] notas = new Nota[NUMERO_NOTAS_MAXIMA];
		
		
	//Constructores
		public Bloc () {}
		
		public Bloc (String nombre) {
			this.nombre = nombre;
		}
		
		
	//Metodos
		public static int getNumeroNotasMaxima() {
			return NUMERO_NOTAS_MAXIMA;
		}
		
		
		public void activa(int numNota) {
			if(numNota < NUMERO_NOTAS_MAXIMA
					&& this.notas[numNotas - 1] != null
					&& this.notas[numNotas - 1] instanceof Activable) {
				
					
					NotaAlarma notaToActivar = (NotaAlarma) this.notas[numNota - 1];
					notaToActivar.activar();

				
			}else {
				throw new NotaAlarmaException("No se ha podido activar la alarma.");
			}
		}
		
		
		public void desactiva(int numNota) {
			if(numNota < NUMERO_NOTAS_MAXIMA
					&& this.notas[numNotas - 1] != null
					&& this.notas[numNotas - 1] instanceof Activable) {
				
					
					NotaAlarma notaToActivar = (NotaAlarma) this.notas[numNota - 1];
					notaToActivar.activar();

				
			}else {
				throw new NotaAlarmaException("No se ha podido desactivar la alarma.");
			}
		}
		
		
		public Nota[] ordenarNotas() {
			
			int contadorNotas = contarNotasNoNulas();
			
			Nota[] notasOrdenadas = new Nota[contarNotasNoNulas()];
			int cNotasOrdenadas = 0;
			
			for (int i = 0; i < this.notas.length; i++) {
				if (this.notas[i] != null) {
					notasOrdenadas[cNotasOrdenadas++] = this.notas[i];
				
				}
			}
			
			Arrays.sort(notasOrdenadas);
			return notasOrdenadas;
		}
		
		
		private int contarNotasNoNulas() {
			int contadorNotas = 0;
			for(int i = 0; i < this.notas.length; i++) {
				if (this.notas[i] != null) {
					contadorNotas++;
				}
			}
		
			return contadorNotas;
		}
		
		public void updateNota(int posicion, String texto) {
			if(posicion < NUMERO_NOTAS_MAXIMA) {
				this.notas[posicion].setTexto(texto);
			}else {
				throw new BlocException();
			}
		}
		
		
		public String getNota(int numNota) {
			String resultado = "";
			if (numNota < NUMERO_NOTAS_MAXIMA && numNota > 0) {
				resultado = this.notas[numNota].toString();
			}
			
			return resultado;
		}
		
		
		public void addNota(Nota nota) {
			if (numNotas < NUMERO_NOTAS_MAXIMA) {
				this.notas[numNotas++] = nota;
				numNotas++;
			}
		}
		
		public void addNota(int posicion, Nota nota) {
			if (posicion < NUMERO_NOTAS_MAXIMA) {
				this.notas[posicion] = nota;
			}else {
				throw new BlocException();
			}
		}
		
		
		public String getNombre() {
			return this.nombre;
		}
		
		
		public String ordenaBloc() {
			return "Return que.";
		}


		@Override
		public String toString() {
			return "Bloc [numNotas=" + numNotas + ", nombre=" + nombre + "]";
		}


		@Override
		public int hashCode() {
			return Objects.hash(nombre, numNotas);
		}


		@Override
		public boolean equals(Object obj) {
			
			boolean sonIguales = false;
			
			if (this == obj)
				sonIguales = true;
			
			if (obj == null)
				sonIguales = false;
			
			if (getClass() != obj.getClass())
				sonIguales = false;
			
			Bloc other = (Bloc) obj;
			
			return sonIguales;
		}

}
