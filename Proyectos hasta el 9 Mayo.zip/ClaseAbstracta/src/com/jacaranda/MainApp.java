package com.jacaranda;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Scanner;

import com.jacaranda.bloc.Bloc;
import com.jacaranda.notas.Nota;
import com.jacaranda.notas.NotaAlarma;
import com.jacaranda.notas.NotaAlarmaException;

public class MainApp {
	
	private static final String MENU_PRINCIPAL = " Menú para crear notas (Introduzca 4 para salir)"
										+ "1. Crear nota \n"
										+ "2. Crear nota alarma\n"
										+ "3. Modificar nota\n"
										+ "4. Salir";
	
	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		imprimirMenuPrincipal();
		
		
		int opcion = Integer.valueOf(sc.nextLine());
		Bloc bloc = new Bloc();
		
		boolean salir = false;
		
		while (!salir) {
			
			if(opcion == 1) {
				System.out.println("Introduzca el texto a incluir en la nota.");
				String texto = sc.nextLine();
				Nota n = new Nota(texto);
				bloc.addNota(n);
			
			}else if(opcion == 2) {
				crearFecha();
			
			}else if (opcion == 3) {
			
			
			}else if (opcion == 4) {
				
				for (Nota n : bloc.ordenarNotas()) {
					System.out.println(n);
					
				}
				
				System.out.println("----");
				
				Nota[] notasOrdenadas = bloc.ordenarNotas();
				for (int i = 0; i < notasOrdenadas.length; i++) {
					System.out.println(notasOrdenadas[i]);
				}
				
			
			}else if (opcion == 5) {
				String respuesta = "";
				
				do {
					System.out.println("Está seguro de que quiere salir (S/N)");
					respuesta = sc.nextLine();
					
				
					
				}while (!("SN".contains(respuesta) || "sn".contains(respuesta)) 
						&& respuesta.length() != 1);
					
				
				if ("S".equalsIgnoreCase(respuesta)) {
					salir = true;
				}
			}
			
			if(!salir) {
				imprimirMenuPrincipal();
				opcion = Integer.valueOf(sc.nextLine());
			}
		}
		
		System.out.println("Has salido de la aplicación.");
		
		/*
		NotaAlarma na = new NotaAlarma("nota alarma");
		
		Bloc bloc = new Bloc();
		
		try {
			bloc.addNota(51, na);
			bloc.activa(2);
			
			System.out.println(Bloc.getNumeroNotasMaxima());

		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
		//bloc.addNota(new Nota("aa"));
		bloc.addNota(na);
		bloc.addNota(na);
		
		bloc.addNota(49, na);

		bloc.activa(2);
		*/
		
		
	}

	public static LocalDateTime crearFecha() {
		System.out.println("Introduzca el día: ");
		int dia = Integer.valueOf(sc.nextLine());
		System.out.println("Introduzca el mes: ");
		int mes = Integer.valueOf(sc.nextLine());
		System.out.println("Introduzca el año: ");
		int year = Integer.valueOf(sc.nextLine());
		
		System.out.println("Introduzca la hora: ");
		int hour = Integer.valueOf(sc.nextLine());
		System.out.println("Introduzca los minutos: ");
		int min = Integer.valueOf(sc.nextLine());
		System.out.println("Introduzca los segundos: ");
		int sec = Integer.valueOf(sc.nextLine());
		
		LocalDateTime fecha = LocalDateTime.of(year, mes, dia, hour, min, sec);
		
		return fecha;
	}
	
	private static void test() {
		Integer[] lista = new Integer[7];
		lista[0] = 10;
		lista[2] = 3;
		lista[3] = 1;
		
		Arrays.sort(lista);
		
	}
	
	private static void imprimirMenuPrincipal() {
		System.out.println(MENU_PRINCIPAL);
	}

	public static void nuevo() {
		Nota[] bloc = new Nota[5];
		for (int i=0; i<bloc.length; i++) {
			bloc[i] = crearNota();
		}
		
		try {
			NotaAlarma notaAlarma = null;
			//notaAlarma = new NotaAlarma("el mensaje");
			notaAlarma.activar();
			System.out.println(notaAlarma.toString());
		
		}catch(Exception e) {
			throw new NotaAlarmaException("Se ha producido una excepción inesperada.", e);
		}
	}
	
	private static Nota crearNota() {
		System.out.println("Introduce un mensaje para la nota: ");
		String texto = new Scanner(System.in).nextLine();
		return new Nota(texto);
	}

}
