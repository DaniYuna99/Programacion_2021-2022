package com.jacaranda.notas;

import java.time.LocalDateTime;

	public abstract class NotaAlarma extends Nota implements Activable {

		//Atributos
		private LocalDateTime fechaAlarma;
		private final Integer MINUTOS_REPETIR_POR_DEFECTO = 0;
		private Integer minutosRepetir;
		private boolean activado;
		
		
		//Constructores
		public NotaAlarma (String a) {
			super(a);
		}

		
		//Getters-Setters
		private void setFechaAlarma(LocalDateTime fechaAlarma) {
			this.fechaAlarma = fechaAlarma;
		}


		public boolean isActivado() {
			return activado;
		}


		public Integer getMINUTOS_REPETIR_POR_DEFECTO() {
			return MINUTOS_REPETIR_POR_DEFECTO;
		}


		@Override
		public String toString() {
			return "NotaAlarma [fechaAlarma=" + fechaAlarma + ", MINUTOS_REPETIR_POR_DEFECTO="
					+ MINUTOS_REPETIR_POR_DEFECTO + ", minutosRepetir=" + minutosRepetir + ", activado=" + activado
					+ "]";
		}
		
		
		
	}
