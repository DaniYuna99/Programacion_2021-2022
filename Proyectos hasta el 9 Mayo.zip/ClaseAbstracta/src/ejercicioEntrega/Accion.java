package ejercicioEntrega;

public abstract class Accion extends Juego {

	public Integer getMuertes() {
		Integer muertes = 0;
		return muertes;
	}
}
