package ejercicioEntrega;

public abstract class Arcade extends Juego {

	public Integer getContinues() {
		Integer continues = 0;
		return continues;
	}
}
