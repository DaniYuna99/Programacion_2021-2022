module lecturaDeXML {
	requires java.xml;
}