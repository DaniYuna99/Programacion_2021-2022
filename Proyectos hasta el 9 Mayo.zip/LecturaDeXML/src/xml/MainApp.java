package xml;

import xml.reader.XMLReader_Coche;
import xml.reader.XMLReader_CasetasFeria;

public class MainApp {

	public static void main(String[] args) {
		
		//XMLReader_Coche reader = new XMLReader_Coche();
		//reader.cargarArchivoDatos("./files/coches.xml");
		
		XMLReader_CasetasFeria reader2 = new XMLReader_CasetasFeria();
		reader2.cargarArchivoDatos("./files/casetasferia.xml");
		
		
		//File file = new File ("./files/casetasferia.xml");
		//System.out.println(file.exists());
	}

}
