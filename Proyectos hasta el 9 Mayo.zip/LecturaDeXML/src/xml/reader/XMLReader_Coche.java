package xml.reader;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import xml.model.Coche;

public class XMLReader_Coche {

	public List<Coche> cargarArchivoDatos(String path) {
		
		List<Coche> coches = new ArrayList<>(); 
		
		File archivo = new File(path);
		
		if (archivo.exists()) {
			try {
				
				DocumentBuilderFactory factory = DocumentBuilderFactory.newDefaultInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();
				Document documento = builder.parse(archivo);
				
				documento.getDocumentElement().normalize();
				
				//Primero obtengo todos los nodos de etiqueta "coche"
				NodeList listaNodos = documento.getElementsByTagName("coche");

				/*Para cada nodo, lo transformo en elemento para acceder
				 * a sus atributos y nodos hijos.*/
				for (int i = 0; i < listaNodos.getLength(); i++) {
					//Transformo mi nodo a Element
					Element elemento = (Element) listaNodos.item(i);
					
					System.out.println(elemento.getAttribute("id"));
					System.out.println(elemento.getElementsByTagName("marca").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("modelo").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("motor").item(0).getTextContent());

					System.out.println(((Element)elemento.getElementsByTagName("ruedas").item(0)).getElementsByTagName("rueda").item(3).getTextContent());
					
					int id = Integer.valueOf(elemento.getAttribute("id"));
					String marca = elemento.getElementsByTagName("marca").item(0).getTextContent();
					String modelo = elemento.getElementsByTagName("modelo").item(0).getTextContent();
					String motor = elemento.getElementsByTagName("motor").item(0).getTextContent(); 
					
					Coche coche = new Coche(id, marca, modelo, motor);
					
					coches.add(coche);
					
				}
								
				
			}catch (ParserConfigurationException e) {
				e.printStackTrace();
			}catch (SAXException e) {
				e.printStackTrace();
			}catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		
		return coches;
	}
}
