package xml.reader;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import xml.model.CasetaFeria;

public class XMLReader_CasetasFeria {

	public List<CasetaFeria> cargarArchivoDatos(String path) {
		
		List<CasetaFeria> casetas = new ArrayList<>(); 
		
		File archivo = new File(path);
		
		if (archivo.exists()) {
			try {
				
				DocumentBuilderFactory factory = DocumentBuilderFactory.newDefaultInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();
				Document documento = builder.parse(archivo);
				
				documento.getDocumentElement().normalize();
				
				//Primero obtengo todos los nodos de etiqueta "coche"
				NodeList listaNodos = documento.getElementsByTagName("DatosLeidos");

				/*Para cada nodo, lo transformo en elemento para acceder
				 * a sus atributos y nodos hijos.*/
				for (int i = 0; i < listaNodos.getLength(); i++) {
					
					//Transformo mi nodo a Element
					Element elemento = (Element) listaNodos.item(i);
					
					System.out.println(elemento.getElementsByTagName("TITULO").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("CALLE").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("NUMERO").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("MODULOS").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("CLASE").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("ID").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("ID_CALLE").item(0).getTextContent());
					
					String titulo = elemento.getElementsByTagName("TITULO").item(0).getTextContent();
					String calle = elemento.getElementsByTagName("CALLE").item(0).getTextContent();
					//Me da error y no s� porqu�. He probado con los tipos primitivos y tambi�n falla.
					//Con la clase Coche me va bien. Imprimir me imprime, pero no crea la clase al dar error,
					//y se para el programa.
					Integer numero = Integer.valueOf(elemento.getElementsByTagName("NUMERO"));
					Integer modulos = Integer.valueOf(elemento.getElementsByTagName("MODULOS"));
					String clase = elemento.getElementsByTagName("CLASE").item(0).getTextContent(); 
					Integer id = Integer.valueOf(elemento.getElementsByTagName("ID"));
					Integer idClase = Integer.valueOf(elemento.getElementsByTagName("ID_CLASE"));

					
					CasetaFeria caseta = new CasetaFeria(titulo, calle, numero, modulos, clase, id, idClase);
					
					casetas.add(caseta);
					
				}
								
				
			}catch (ParserConfigurationException e) {
				e.printStackTrace();
			}catch (SAXException e) {
				e.printStackTrace();
			}catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		
		return casetas;
	}
}

