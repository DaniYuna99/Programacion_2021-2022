package test.java.com;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;

import main.java.com.util.ColeccionUtilidades;
import main.java.com.util.Persona;

public class ColeccionUtilidadTest {

	@Test
	public void testPrimerElementoEsFelipe() {
		List<Persona> lista = ColeccionUtilidades.generarListaPersonas();
		ColeccionUtilidades.ordenarListaPersonas(lista);
		assertEquals(lista.get(0).getApellidos(), "Acosta");
	}
	
	@Test
	public void testUltimoElementoEsQiaz() {
		List<Persona> lista = ColeccionUtilidades.generarListaPersonas();
		ColeccionUtilidades.ordenarListaPersonas(lista);
		assertEquals(lista.get(4).getApellidos(), "Qiaz");
	}
	
	@Test
	public void testNoFallaAlOrdenarConjuntoNull() {
		
	}
	
	
	@Test
	public void testNoFallaAlOrdenarConjuntoVacio() {
		assertEquals(ColeccionUtilidades.ordenarListaPersonas(null), null);
	}

}
