package main.java.com.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ColeccionUtilidades {

	public static void trabajarConColecciones () {}
	
	
	public static List<Persona> generarListaPersonas() {
		
		List<Persona> lista = new ArrayList<>();
		
		lista.add(new Persona("Joseba", "Diaz", 20, 1.80, "Hombre"));
		lista.add(new Persona("Antonio", "González", 20, 1.80, "Hombre"));
		lista.add(new Persona("Felipe", "Acosta", 20, 1.80, "Hombre"));
		lista.add(new Persona("MJ", "JM", 20, 1.80, "Hombre"));
		lista.add(new Persona("hDFG", "Qiaz", 20, 1.80, "Hombre"));
		
		
		return lista;
	}
	
	public static List<Persona> ordenarListaPersonas(List<Persona> personas) {
		
		if(personas != null) {
			Collections.sort(personas);
		}
		
		return personas;
	}
}
