package main.java.com.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class EjemplosConjuntos {

	public EjemplosConjuntos() {}
	
	public static void pruebaComparacionColecciones() {
		
		/*List<Integer> lista = new ArrayList<>();
		System.out.println("Debo tener la secuencia: 8, 8, 8, 14, 7, 2, 3, null");
		cargarColeccion(lista);
		
		Set<Integer> conjunto = new HashSet<Integer>();
		System.out.println("Debo tener los números: null, 2, 3, 7, 8, 14");
		cargarColeccion(conjunto);*/
		
		List<Persona> listaPersona = new ArrayList<>();
		System.out.println("Algo");
		cargarColeccionPersona(listaPersona);
		
		Set<Persona> conjuntoPersona = new HashSet<>();
		System.out.println("Algo2");
		cargarColeccionPersona(conjuntoPersona);

	}
	
	public static void cargarColeccionPersona (Collection<Persona> coleccionPersona) {
		
		Persona persona = null;
		
		coleccionPersona.add(persona = new Persona("Daniel", "Carpintero Quesada", 22, 1.80, "Hombre"));
		coleccionPersona.add(persona = new Persona("Daniel", "Carpintero Quesada", 22, 1.80, "Hombre"));
		coleccionPersona.add(persona = new Persona("Daniel", "Carpintero Quesada", 22, 1.80, "Hombre"));
		coleccionPersona.add(persona = new Persona("Daniel", "Carpintero Quesada", 22, 1.80, "Hombre"));
		coleccionPersona.add(persona = new Persona("Daniel", "Carpintero Quesada", 22, 1.80, "Hombre"));

		System.out.println(coleccionPersona);
		System.out.println(coleccionPersona.size());
	}
	
	public static void cargarColeccion (Collection<Integer> coleccionDeNumeros) {
		
		coleccionDeNumeros.add(8);
		coleccionDeNumeros.add(8);
		coleccionDeNumeros.add(8);
		coleccionDeNumeros.add(14);
		coleccionDeNumeros.add(7);
		coleccionDeNumeros.add(2);
		coleccionDeNumeros.add(3);
		coleccionDeNumeros.add(null);

		System.out.println(coleccionDeNumeros);
		System.out.println(coleccionDeNumeros.size());
	}
	
	
}
