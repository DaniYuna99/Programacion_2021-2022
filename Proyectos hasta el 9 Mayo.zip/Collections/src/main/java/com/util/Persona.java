package main.java.com.util;

public class Persona implements Comparable<Persona> {

	private String nombre;
	private String apellidos;
	private Integer edad;
	private Double altura;
	private String sexo;
	
	
	public Persona (String nombre, String apellidos, Integer edad,
			Double altura, String sexo) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.edad = edad;
		this.altura = altura;
		this.sexo = sexo;
	}
	
	public boolean esMayorEdad(Persona persona) {
		boolean esMayor = false;
		
		if(persona.getEdad() >= 18) {
			esMayor = true;
		}
		
		return esMayor;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getApellidos() {
		return apellidos;
	}


	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}


	public Integer getEdad() {
		return edad;
	}


	public void setEdad(Integer edad) {
		this.edad = edad;
	}


	public Double getAltura() {
		return altura;
	}


	public void setAltura(Double altura) {
		this.altura = altura;
	}


	public String getSexo() {
		return sexo;
	}


	public void setSexo(String sexo) {
		this.sexo = sexo;
	}


	@Override
	public String toString() {
		return "Persona [nombre=" + nombre + ", apellidos=" + apellidos + ", edad=" + edad + ", altura=" + altura
				+ ", sexo=" + sexo + "]";
	}
	
	@Override
	public int compareTo(Persona otraPersona) {
		
		int resultado = 0;
		
		if(this.getApellidos() != null && otraPersona.getApellidos() != null) {
			
			if(this.getApellidos().compareTo(otraPersona.getApellidos()) < 0) {
				resultado = -1;
			}else if(this.getApellidos().compareTo(otraPersona.getApellidos()) > 0) {
				resultado = 1;
			}
		}
		
		
		return resultado;
	}
}
