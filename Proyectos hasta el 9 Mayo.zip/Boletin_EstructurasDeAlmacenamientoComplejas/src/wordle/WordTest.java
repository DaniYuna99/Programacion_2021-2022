package wordle;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class WordTest {
	
	private Word word;
	
	@BeforeEach
	void setUp() {
		word = new Word();
	}
	

	@ParameterizedTest
	@ValueSource(strings = {"ala", "radar"})
	void testEsPalindromo(String palabra) {
		assertTrue(new Word().esPalindromo(palabra));

	}
	
	@ParameterizedTest
	@ValueSource(strings = {"alac", "radard"})
	void testNoEsPalindromo(String palabra) {
		assertFalse(new Word().esPalindromo(palabra));

	}
	

}
