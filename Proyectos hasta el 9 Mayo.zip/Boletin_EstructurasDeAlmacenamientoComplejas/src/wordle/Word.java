package wordle;

import java.util.List;

public class Word {

	public Word() {}
	
	public boolean esPalindromo(String palabraAcomprobar) {
		
		boolean pali = palabraAcomprobar != null;
		
		if(pali) {
			
			int longitudPalabra = palabraAcomprobar.length();
			
			for(int i = 0; i < longitudPalabra / 2; i++) {
				if(palabraAcomprobar.charAt(i) != palabraAcomprobar.charAt(longitudPalabra-i-1)) {
					pali = false;
				}
			}
		}
		
		return pali;
	}
	
}



