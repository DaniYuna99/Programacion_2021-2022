package maquinaCafe;

import java.util.HashMap;
import java.util.Map;

public class Monedero {
	
	private static final Integer OCHENTA = 80;
	private static final Integer VEINTE = 20;
	private static final Integer QUINCE = 15;
	private static final Integer CUARENTA = 40;


	private Map<Moneda, Integer> cantidades;
	
	public Monedero() {
		cantidades = new HashMap<Moneda, Integer>();
	}
	
	public void inicializarMonedero() {
		cantidades.put(Moneda.FIVECENT, 	OCHENTA);
		cantidades.put(Moneda.TENCENT, 		CUARENTA);
		cantidades.put(Moneda.TWENTYCENT, 	VEINTE);
		cantidades.put(Moneda.FIFTYCENT, 	VEINTE);
		cantidades.put(Moneda.EURO, 		VEINTE);
		cantidades.put(Moneda.TWOEURO, 		QUINCE);
	}
	
	public Integer calcularCambio(Map<Moneda, Integer> pago, Integer precio) {
		
		if(calcularPago(pago)>= precio) {
			
		}else {
			
		}
		
		
		return null;
	}
	
	
	public Integer calcularPago(Map<Moneda, Integer> pago) {
		
		Integer cantidad = 0;
		for(Moneda m : pago.keySet()) {
			cantidad += pago.get(m) * m.value;
		}
		return cantidad;
	}
	
	
	
	
}
