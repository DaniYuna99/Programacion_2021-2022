package maquinaCafe;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

class MonederoTest {

	@Test
	void test() {
		Monedero mon = new Monedero();
		
		Map<Moneda, Integer> pago = new HashMap<>();
		pago.put(Moneda.TWOEURO, 2);
		pago.put(Moneda.EURO, 1);
		pago.put(Moneda.TWOEURO, 1);

		
		assertEquals(mon.calcularCambio(pago, 50), 150);
	}
}
