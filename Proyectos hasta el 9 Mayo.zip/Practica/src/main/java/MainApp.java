package main.java;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Pon tu nombre, y te saludar�:");
		String nombre = String.valueOf(sc.nextLine());
		LocalTime hora = LocalTime.now();
		LocalDate diaDeHoy = LocalDate.now();
		System.out.println("Hola " + nombre + ". Encantado de conocerlo.");
		System.out.print("Son las:\n");
		System.out.println(hora + " ahora mismo.");
		System.out.println("Y es el d�a: " + diaDeHoy + ".");
	}

}
