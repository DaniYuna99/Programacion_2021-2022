package yoksetioxddd;

public class Persona {

	private String nombre;
	private int edad;
}
