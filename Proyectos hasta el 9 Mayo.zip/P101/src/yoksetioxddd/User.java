package yoksetioxddd;

public class User {

	/**yoquesé
	 * 
	 *
	 */
	
}
