package com.edu;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Hey buenas a todos, aquí Willyrex comentando.");

	}

}
