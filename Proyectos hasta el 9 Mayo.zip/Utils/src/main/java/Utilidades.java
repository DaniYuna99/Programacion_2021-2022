package main.java;

import java.util.ArrayList;
import java.util.List;

public class Utilidades {

	/**
	 * Metodo generico que recibe un array de cualquier clase 
	 * y devuelve un array del mismo tamano, pero en orden
	 * inverso. Si el objeto que recibe es nulo (null), 
	 * se devuelve el mismo objeto. Si esta vacio, se devuelve
	 * un array del mismo tipo vacio o sin elementos
	 * 
	 * @param <T> Tipo generico que puede utilizarse con 
	 * cualquier objeto
	 * @param arrayOriginal array a invertir
	 * @return array invertido
	 */
	public static <T> T[] reverse (T[] arrayOriginal) {
		
		T[] arrayInvertido = null;
		
		if(arrayOriginal != null) {
		
			arrayInvertido = arrayOriginal.clone();
			
			for (int i = 0; i < arrayOriginal.length; i++) {
				arrayInvertido[i] = arrayOriginal[arrayOriginal.length -1 -i];
			}
		
		}
		
		return arrayInvertido;
	}
	
	
	public boolean esCapicua(Integer numero) {
		
		String numero2 = String.valueOf(numero);
		
		for (int i = 0; i < numero2.length(); i++) {
			if(numero2[i])
		}
		
		
		return false;
	}
	
	
	public boolean esCapicua(String numero) {
		
		
		
		
		return false;
	}
	
	
	public boolean esCapicua(Double numero) {
		
		
		
		
		return false;
	}
	
	
	public boolean esAnagrama(String palabra) {
		
		boolean resultado = false;
		
		for(int i = 0; i < palabra.length(); i++) {
			
		}
		
		return resultado;
	}
}
