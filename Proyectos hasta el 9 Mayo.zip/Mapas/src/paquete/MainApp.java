package paquete;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainApp {

	public static void main(String[] args) {
																 
		List<Integer> listaNumeros = new ArrayList<>();					
		listaNumeros.add(1);
		listaNumeros.add(1);
		listaNumeros.add(1);
		listaNumeros.add(1);
		listaNumeros.add(3);
		listaNumeros.add(3);
		//listaNumeros.add(4);
		listaNumeros.add(4);
		System.out.println(cuentaNumeros(listaNumeros));
		
		
		List<String> listaPalabras = new ArrayList<>();
		listaPalabras.add("Hola");		
		listaPalabras.add("Hola");
		listaPalabras.add("Prueba");
		listaPalabras.add("Ejemplo");
		listaPalabras.add("Ejemplo");
		listaPalabras.add("Hola");
		listaPalabras.add("Hola");
		listaPalabras.add("Hola");
		listaPalabras.add("Hola");
		listaPalabras.add("Hola");
		listaPalabras.add("Hola");
		listaPalabras.add("Ejemplo");
		listaPalabras.add("Ejemplo");
		listaPalabras.add("Ejemplo");
		listaPalabras.add("Ejemplo");


		System.out.println(cuentaElementos(listaPalabras));


																	
	}

	public static Map<Integer, Integer> cuentaNumeros(List<Integer> numeros) {  
				
		Map<Integer, Integer> res = new HashMap<>();
		int x;
		
		for (Integer i : numeros) {
			if (res.containsKey(i)) {
				x = res.get(i);
				x++;
				res.put(i, x);
			}else {
				x = 1;
				res.put(i, x);
			}
		}
		return res;
		
	}
	
	
	public static <T> Map <T, Integer> cuentaElementos (Collection<T> coleccion) {
		
		Map <T, Integer> res = new HashMap<>();
		int x;
		
		for (T i : coleccion) {
			if (res.containsKey(i)) {
				x = res.get(i);
				x++;
				res.put(i, x);
			}else {
				x = 1;
				res.put(i, x);
			}
		}
		
		return res;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
