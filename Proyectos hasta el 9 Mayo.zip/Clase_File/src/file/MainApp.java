package file;

import java.io.File;
import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) {
		
		/*File fichero = new File("/home/estudiante/fichero.txt");
		fichero.mkdir();
		
		System.out.println(fichero.exists());
		System.out.println(fichero.isFile());
		System.out.println(fichero.length());
		System.out.println(fichero.getAbsolutePath());
		System.out.println(fichero.getName());*/
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Ruta donde quieres crear el archivo: ");
		String ruta = String.valueOf(scanner.nextLine());
		System.out.println("Nombre del archivo: ");
		String nombreArchivo = String.valueOf(scanner.nextLine());

		crearEstructuraDirectorios(ruta, nombreArchivo);
		
		scanner.close();
		
	}
	
	public static void crearEstructuraDirectorios(String ruta, String nombreArchivo) {
		
		File raiz = new File(ruta);
		
		if (raiz.exists() && raiz.canWrite()) {
			File directorioPrincipal = new File(ruta + "/" + nombreArchivo);
			directorioPrincipal.mkdir();
			
			for(int i = 1; i <= 50; i++) {
				File subcarpeta = new File(directorioPrincipal.getAbsolutePath() + "tmp" + i);
				subcarpeta.mkdir();
				
				new File(subcarpeta.getAbsolutePath() + "/subcarpeta1").mkdir();
				new File(subcarpeta.getAbsolutePath() + "/subcarpeta2").mkdir();

			}
		}
		
		
	}

}
