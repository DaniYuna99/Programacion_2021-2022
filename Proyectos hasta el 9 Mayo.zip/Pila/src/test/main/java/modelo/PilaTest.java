package test.main.java.modelo;

import org.junit.jupiter.api.Test;

import main.java.modelo.Pila;

class PilaTest {

	@Test
	void testPush() {
		Pila<Integer> pila = new Pila();
		pila.push(1);
		pila.push(2);
		pila.push(0);
		assertEquals(pila.size(), 3);
	}

	
	@Test
	void testPop() {
		
		Pila<Integer> pila = new Pila();
		assertNull(pila.pop());
		
		pila.push(2);
		pila.push(3);
		pila.push(0);
		assertEquals(pila.pop(), 0);
		assertEquals(pila.pop(), 3);
		assertEquals(pila.pop(), 2);

		
	}