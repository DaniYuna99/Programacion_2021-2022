package siete_y_media;

public class Baraja {

	//Atributos
	private Integer numCartas;
	private Integer siguiente;
	
	//public Carta;
	
	
	
	
	//Constructores
	public Baraja() {}
	
	
	
	
	//Metodos
	public void barajar() {
		
	}
	
	
	
	private String generaPalo() {
		
		return null;
	}
	
	
	private int generaNumero() {
		
		return 0;
	}


	
	
	//Getters-Setters
	public Integer getNumCartas() {
		return numCartas;
	}


	public void setNumCartas(Integer numCartas) {
		this.numCartas = numCartas;
	}
	
	
	public Carta getSiguiente() {
			
		return null;
	}


	public void setSiguiente(Integer siguiente) {
		this.siguiente = siguiente;
	}


	
	
	//toString()
	@Override
	public String toString() {
		return "Baraja numCartas= " + numCartas + ", siguiente= " + siguiente;
	}
	
	
	
}
