package siete_y_media;

import java.util.Objects;

public class Carta {
	
	//Atributos
	private Integer number;
	private String palo;
	
	
	
	
	//Constructores
	public Carta () {}
	
	public Carta (int number, String palo) {
		this.number = number;
		this.palo = palo;
	}
	
	
	
	
	//Metodos
	public double getValor() {
		
		return 0.0;
	}

	
	
	
	//Getters-Setters
	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public String getPalo() {
		return palo;
	}

	public void setPalo(String palo) {
		this.palo = palo;
	}

	
	
	
	//equals y hashCode
	
	@Override
	public int hashCode() {
		return Objects.hash(number, palo);
	}

	@Override
	public boolean equals(Object obj) {
		boolean sonIguales = false;
		
		if (this == obj)
			sonIguales = true;
		if (obj == null)
			sonIguales = true;
		if (getClass() != obj.getClass())
			sonIguales = true;
		Carta other = (Carta) obj;
		
		return sonIguales;
	}

	
	
	
	//toString()
	
	@Override
	public String toString() {
		return "Carta number= " + number + ", palo= " + palo;
	}
	
	
	
	
}
