package siete_y_media;

public class Principal {

	public static void main(String[] args) {

		Carta carta1= new Carta(1, "Palo");
		
	}

}
