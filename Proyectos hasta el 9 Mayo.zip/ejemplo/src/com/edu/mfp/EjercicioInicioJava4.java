package com.edu.mfp;

public class EjercicioInicioJava4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*4. Calcular las calificaciones de un alumno con un método que reciba la nota de la parte
		práctica, la nota de los problemas y la parte teórica. La nota final se calcula según el
		siguiente criterio: la parte práctica vale el 10%; la parte de problemas vale el 50% y la parte
		teórica el 40%. Las notas deben estar entre 0 y 10, si no lo están, deberá devolver un
		mensaje de error. Realiza el método que calcule la media de tres notas y te devuelva la nota
		del boletín (insuficiente, suficiente, bien, notable o sobresaliente).*/
		
		System.out.println(calcularCalificaciones(9, 7, 7));

	}
	
	public static String calcularCalificaciones (int practica, int problemas, int teorica) {
		
		String resultado = " ";
		
		double medianotas = ((practica * 0.10) + (problemas * 0.5) + (teorica * 0.4));
		
		if (medianotas < 5) {
			resultado = "Insuficiente.";
		}else if (medianotas == 5) {
			resultado = "Suficiente.";
		}else if (medianotas > 6 && medianotas < 9) {
			resultado = "Notable.";
		}else if (medianotas >= 9 && medianotas <= 10) {
			resultado = "Sobresaliente.";
		}else {
			resultado = "Ha habido un error en la introducción de datos.";
		}
		
		return resultado;
	}

}
