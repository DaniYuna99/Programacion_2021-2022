package com.edu.mfp;

import java.util.Scanner;

public class EjercicioInicioJava7_Hechopormi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//7. Método que muestre los números del 1 al 100 utilizando la instrucción for (para)
		
		//NOTA: Si te dice el ejercicio "muestre" quiere decir mostrarlo en consola.
		
		System.out.println("Programa para contar números hasta un límite.");
		System.out.println("Introduce el límite y el programa contará desde 1 hasta ese número:");
		Scanner scanner = new Scanner (System.in);
		int limiteMaximo = Integer.valueOf(scanner.next());
		
		forHastaelLimite(limiteMaximo);
		
		scanner.close();
		
	}
	
	public static void forHastaelLimite (int limite) {
		
		for (int i = 1; i <= limite; i++) {
			System.out.println(i);
		}
	}
}
