package com.edu.mfp;

import java.util.Scanner;

public class Ejercicio3_Solucion_maestro {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//while (true) {
			System.out.println("Dime el mes.");
			Scanner sc = new Scanner (System.in);
			int mes = Integer.valueOf(sc.next());
			
			
			System.out.println("Dime el año.");
			Scanner sc2 = new Scanner (System.in);
			int year = Integer.valueOf(sc2.next());
			
			switch (mes) {
			
				case 1, 3, 5, 7, 8, 10, 12:
					System.out.println("El mes tiene 31 días.");
					break;
					
				case 2:
					if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) {
					System.out.println("El mes tiene 29 días.");
					}else {
						System.out.println("El mes tiene 28 días.");
					}
					break;
					
				case 4, 6, 9, 11:
					System.out.println("El mes tiene 30 días.");
					break;
					
				default:
					System.out.println("El mes introducido no es válido.");
					break;
				
			}
			
			//Línea separadora vendría aquí para separar los bucles visualmente. La línea puede convertirse en función
			//y puede ser llamada mediante System.out.println(LINEA_SEPARADORA)
			
			sc.close();
			sc2.close();

		}

	}
	

