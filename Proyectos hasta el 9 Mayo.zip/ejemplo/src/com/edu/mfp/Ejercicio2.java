package com.edu.mfp;

import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*Modifica el programa anterior para que indique el grupo de edad al 
		 *que pertenece (niñ@ < 18, adulto, ancian@ > 65 */
		
		System.out.println("¿Qué edad tienes?");
		int edad;
		Scanner scanner = new Scanner (System.in);
		edad = Integer.valueOf(scanner.next());
		scanner.close();
		
		if (edad < 18) {
			System.out.println("Eres un niño.");
		}else if (edad >= 18 && edad < 65) {
			System.out.println("Eres adulto.");
		}else if (edad >= 65 && edad < 123) {
			System.out.println("Eres un anciano.");
		}else if (edad >= 123) {
			System.out.println("Por supuesto que me creo que tengas más de 122, más que Jeanne Calment, la mujer más longeva registrada.");
		}

	}

}