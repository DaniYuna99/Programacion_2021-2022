package com.edu.mfp;

import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*Realiza un programa (días del mes) que pregunte por un año y un mes y 
		 *devuelva el número de días que tiene ese mes para el
		 *año especificado.*/
		
		System.out.println("Dime el mes.");
		Scanner sc = new Scanner (System.in);
		int mes = Integer.valueOf(sc.next());
		
		
		System.out.println("Dime el año.");
		Scanner sc2 = new Scanner (System.in);
		int year = Integer.valueOf(sc2.next());
		
		
		switch (mes) {
			case 1: {
				System.out.println("Enero tiene 31 días.");
				break;
			}case 2: { //No puedo hacer lo de la detección del año bisiesto, no me entero nunca.
				if (year % 4 == 0 && year % 100 != 0 && year % 400 == 0) {
					System.out.println("Febrero tiene 29 días al ser un año bisiesto.");
				}else {
					System.out.println("Febrero tiene 28 días.");
				}
				break;
			}case 3: {
				System.out.println("Marzo tiene 31 días.");
				break;
			}case 4: {
				System.out.println("Abril tiene 30 días.");
				break;
			}case 5: {
				System.out.println("Mayo tiene 31 días.");
				break;
			}case 6: {
				System.out.println("Junio tiene 30 días.");
				break;
			}case 7: {
				System.out.println("Julio tiene 31 días.");
				break;
			}case 8: {
				System.out.println("Agosto tiene 31 días.");
				break;
			}case 9: {
				System.out.println("Septiembre tiene 30 días.");
				break;
			}case 10: {
				System.out.println("Octubre tiene 31 días.");
				break;
			}case 11: {
				System.out.println("Noviembre tiene 30 días.");
				break;
			}case 12: {
				System.out.println("Diciembre tiene 31 días.");
				break;
			}default:
				System.out.println("El número introducido no es válido.");
			}
		sc.close();
		sc2.close();
	}
}