package com.edu.mfp;

public class EjercicioInicioJava6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*6. Programar un sistema de calefacción-refrigeración que compruebe en función del día y el
		mes la estación en la que estamos y en función de la estación programe la temperatura:
		Invierno->19º, Primavera->20º, Verano->24º, Otoño→19º. El método deberá recibir como
		parámetro el mes y el día actual, y el método deberá devolver los grados a los que
		deberemos programar el sistema.*/
		
		System.out.println(sistemaRefigeracion(1,12)); //19
		System.out.println(sistemaRefigeracion(31,12)); //19
		System.out.println(sistemaRefigeracion(7,7)); //24
		System.out.println(sistemaRefigeracion(1,4)); //20
	}
	
	public static double sistemaRefigeracion (int dia, int mes) {
		
		double temperatura = 0.0;
		
		if (mes == 7 || mes == 8 || mes == 9 && dia < 23 || mes == 6 && dia >= 21) {
			temperatura = 24;
		}else if (mes == 4 || mes == 5 || mes == 6 && dia < 21 || mes == 3 && dia >= 21) {
			temperatura = 19;
		}else {
			temperatura = 19;
		}
		
		return temperatura;
	}
		
	public static boolean esBisiesto (int year) {
		return year%4==0 && (year%100!=0 || year%400==0);
	}
	
	//Incompleto porque lo ha dejado así el maestro
	public static boolean esFechaValida (int dia, int mes, int year) {
		
		if (esBisiesto(year) && mes==2 && dia<=29 && dia>0) {
			
		}
		
		return false;
	}
}


