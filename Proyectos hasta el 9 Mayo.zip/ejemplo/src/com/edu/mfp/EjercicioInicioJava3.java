package com.edu.mfp;

public class EjercicioInicioJava3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/* 3. Escribir un método que reciba un carácter y devuelva el tipo que es. 
		 * Debe devolver una de las se imprimir los siguientes mensajes según corresponda.
		◦ Letra mayúscula
		◦ Letra minúscula
		◦ Dígito entre 0 y 9
		◦ Signo de puntuación
		◦ Espacio en blanco
		◦ Paréntesis () o llaves {}
		◦ Otro carácter
		 * 
		*/
		
		System.out.println("Introduce un caracter de cualquier tipo y te diré qué tipo es:");
		System.out.println(analisisCaracter('´'));
		
		
	}
	
	
	public static String analisisCaracter(char caracter) {
		
		String resultado = " ";
		
		if (Character.isUpperCase(caracter) == true) {
			resultado = "El caracter que has puesto es una letra mayúscula.";
		}else if (Character.isLowerCase(caracter) == true) {
			resultado = "El caracter que has puesto es una letra minúscula.";
		}else if (Character.isDigit(caracter) == true) {
			resultado = "El caracter que has puesto es un dígito.";
		}else if (Character.isSpaceChar(caracter) == true) {
			resultado = "No has puesto un caracter.";
		}else if (caracter == '(' || caracter == ')') {
			resultado = "Es un paréntesis.";
		}else if (caracter == '{' || caracter == '}') {
			resultado = "Es una llave.";
		}else if (caracter == '`' || caracter == '´') {
			resultado = "Es un signo de puntuación.";
		}else {
			resultado = "Otro carácter.";
		}
		
		return resultado;
	}
	
}
