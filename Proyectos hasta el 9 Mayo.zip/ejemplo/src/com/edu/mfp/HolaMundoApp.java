package com.edu.mfp;

import java.util.Scanner;

public class HolaMundoApp {
	
	/**
	 * Comentario de 
	 * varias 
	 * líneas
	 */

	public static void main(String[] args) {
		
		//Variables de tipo básicos
		long tipoLong = 1_000_000_000;
		int entero = 1_000_000;
		char c = 'C';
		int numero = c;
		boolean variableBooleana = false;
		float flo = 1.23f;
		byte byt = -45;
		double dou = 4356.66655d;
		short sho = 432;
		
		//Comentario de una línea
		
		/*Esto es un 
		 * comentario de 
		 * varias líneas*/
		
		//Declaración y definición de variables
		int num1;
		num1 = 2;
		int num2 = 3, num3 = 4;
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
		
		//Constantes (es imposible de cambiar el valor una vez declarada y definida)
		final float floatie = 34.54f;
		final int MAYORIA_EDAD = 546;
		
		System.out.println(floatie);
		System.out.println(MAYORIA_EDAD);
		
		//Incremento y decremento(?) en 1 unidad
		int valor = 9;
		System.out.println(valor);
		
		valor ++;
		System.out.println(valor);
		
		valor --;
		System.out.println(valor);
		
		//Lógica booleana, cambiar entre False a True con negaciones
		boolean logica = false;
		logica = !logica;
		System.out.println(logica);
		
		logica = !logica;
		System.out.println(logica);
		
		logica = !logica;
		System.out.println(logica);
	
		
		System.out.println(tipoLong);
		System.out.println(entero);
		System.out.println(c);
		System.out.println(numero);
		System.out.println(variableBooleana);
		System.out.println(flo);
		System.out.println(byt);
		System.out.println(dou);
		System.out.println(sho);
		
		
		//Scanner: introducción de datos mediante teclado (input en Python)
		String name;
		int edad;
		
		System.out.println("¿Cómo te llamas?");
		
		//Hay que declarar primero el Scanner. El scanner naranja es el nombre de la variable, se puede modificar.
		//El Scanner hay que cerrarse con el nombre de la variable Scanner + .close();
		Scanner scanner = new Scanner(System.in); scanner.close();
		name = scanner.next();
		
		System.out.println("¿Cuál es tu edad?");
		//Se asigna el Scanner a una variable. El 'Integer.valueOf' parece que hay que ponerse para las variables int
		edad = Integer.valueOf(scanner.next());
		
		System.out.println("Hola, " + name);
		System.out.println("Tienes " + edad + " años");
		
		//Las llaves se pueden no poner, pero sólo detectaría la orden siguiente, y si ese if tuviera más órdenes, no saldrían. 
		//Por lo que es mejor poner las llaves siempre.
		if (edad >= 18) {
			System.out.println("Eres mayor de edad.");
		}
		
		//If/Else
		int dia;
		
		System.out.println("¿Qué día de la semana es hoy? (Contesta con números del 1 al 7)");
		Scanner sc = new Scanner(System.in); sc.close();
		dia = Integer.valueOf(sc.next());
		
		if (dia == 1) {
			System.out.println("Lunes");
		}else if (dia == 2) {
			System.out.println("Martes");
		}else if (dia == 3) {
			System.out.println("Miércoles");
		}else if (dia == 4) {
			System.out.println("Jueves");
		}else if (dia == 5) {
			System.out.println("Viernes");
		}else if (dia == 6) {
			System.out.println("Sábado");
		}else if (dia == 7) {
			System.out.println("Domingo");
		}else {
			System.out.println("El día introducido no es válido.");
		}

	
		System.out.println("¿Eres mayor de edad?");
		
		boolean abierto = true;
		
		if (edad >= 18) {
			abierto = true;
		}else {
			abierto = false;
		}
			
		
		if (abierto == true) {
			System.out.println("Puede pasar.");
		}else {
			System.out.println("No puede pasar.");
		}
		}
	
	//

	}



