package com.edu.mfp;

import java.util.Scanner;

public class Condiciones {
	
	public static void main(String[] args) {
		
		/*for --> ( 1: declaración y definición contador;
		 * 			2: condición;
		 * 			3: actualización del contador
		 * 
		*/
		
		for (int i = 1; i <= 10; i++) {
			System.out.println(i*2);
		}
		
		
		int j = 1;
		while (j <= 10) {
			System.out.println(j*2);
			j++;
		}
		
		
		/*Scanner scanner = new Scanner (System.in);
		int numero = 0;
		
		while (numero > 0) {
			System.out.println("Introduzca un número.");
			//Integer.valueOf(scanner.next()) --> Lo que estás diciendo con esto es que 
			//lo que se introduzca en el Scanner, se convierta a un número entero.
			numero = Integer.valueOf(scanner.next());
			if (numero % 2 == 0) {
				System.out.println("El número es par.");
			}else {
				System.out.println("El número es impar.");
			}
		};
		
		scanner.close();*/
		
		//DO-WHILE
		
		/*Scanner scanner2 = new Scanner (System.in);
		int numero2 = 0;
		
		do {
			System.out.println("Introduzca un número.");
			numero2 = Integer.valueOf(scanner2.next());
			if (numero2 % 2 == 0) {
				System.out.println("El número es par.");
			}else {
				System.out.println("El número es impar.");
			}
		}while (numero2 > 0);
		
		scanner2.close();*/
		
		
		/*Scanner scanner3 = new Scanner (System.in);
		int numero3 = 0;
		
		for (int i = 0; i < 10 && numero3 < 0 ; i++) {
			System.out.println("Introduzca un número.");
			numero3 = Integer.valueOf(scanner3.next());
			if (numero3 % 2 == 0) {
				System.out.println("El número es par.");
			}else {
				System.out.println("El número es impar.");
			}
		}
		
		scanner3.close();*/
		
		
		boolean bisiesto = (year % 4 == 0 && (!(year%100 == 0))) ? 28 : 29; //Incompleto
		
		
	}

}
