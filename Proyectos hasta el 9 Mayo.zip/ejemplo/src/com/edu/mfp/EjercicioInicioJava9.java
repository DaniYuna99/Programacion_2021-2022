package com.edu.mfp;

import java.util.Scanner;

public class EjercicioInicioJava9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/* 9. Método que muestre los números del 1 al 100 utilizando 
		 * la instrucción do.while (repetir .. hasta)*/
		
		System.out.println("Programa que repita números hasta el que se indique con un Do-While.");
		System.out.println("Determina el número para que el programa cuente hasta él.");
		Scanner scanner = new Scanner (System.in);
		int limite = Integer.valueOf (scanner.next());
		
		doWhileHastaelLimite(limite);
		
		scanner.close();

	}
	
	public static void doWhileHastaelLimite(int limit) {
		
		int acumulador = 1;
		
		do {
			System.out.println(acumulador);
			acumulador++;
		
		}while (acumulador < limit + 1);
	}

}
