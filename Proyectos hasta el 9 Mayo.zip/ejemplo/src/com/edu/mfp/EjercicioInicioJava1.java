package com.edu.mfp;

import java.util.Scanner;

public class EjercicioInicioJava1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1. Realizar un método que reciba dos números y devuelva True si uno es múltiplo del otro
		
		Scanner scanner = new Scanner (System.in);
		int num1 = Integer.valueOf(scanner.next());
		Scanner scanner2 = new Scanner (System.in);
		int num2 = Integer.valueOf(scanner2.next());
		
		if (num2 % num1 == 0) {
			System.out.println("El primer número es múltiplo del segundo.");
		}else {
			System.out.println("El primer número no es múltiplo del segundo.");
		}
		
		scanner.close();
		scanner2.close();

	}

}
