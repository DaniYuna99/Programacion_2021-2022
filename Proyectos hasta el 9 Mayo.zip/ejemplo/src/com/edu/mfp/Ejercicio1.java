package com.edu.mfp;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1. Diseña un programa que pregunte por la edad de una persona e imprima si es mayor de edad.
		
		System.out.println("¿Qué edad tienes?");
		int edad;
		Scanner scanner = new Scanner (System.in);
		edad = Integer.valueOf(scanner.next());
		scanner.close();
		
		if (edad >= 18) {
			System.out.println("Eres mayor de edad.");
		}else {
			System.out.println("No eres mayor de edad.");
		}

	}

}
