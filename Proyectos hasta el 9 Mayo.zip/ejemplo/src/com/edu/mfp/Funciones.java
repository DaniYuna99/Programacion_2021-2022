package com.edu.mfp;

public class Funciones {
	
	//Funciones. El void se puede sustituir por otras como boolean. 
	//El void se usa para omitir el comando return para llamar la función
			
	public static void esPrimo() {
				
		//Cómo detectar que un número es primo
				
		boolean esPrimo = true;
		int numero = 153;
				
		for (int i = 2 ; i < numero && esPrimo ; i++) {
			if (numero % i == 0) {
				esPrimo = false;
			}
		}
	}
			
			//Cómo llamar una función ya declarada y echa.
			
			esPrimo();
			

}
