package main.java.euro.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Objects;

public class Combinacion {
	
	public static final int VALOR_MINIMO = 1;
	public static final int VALOR_MAXIMO_NUMEROS = 50;
	public static final int VALOR_MAXIMO_ESTRELLAS = 12;
	public static final int TOTAL_NUMEROS = 5;
	public static final int TOTAL_ESTRELLAS = 2;
	
	//Atributos
	private Collection<Integer> numeros;
	private Collection<Integer> estrellas;
	
	
	//Constructores
	/**
	 * Constructor que recoge los números y estrellas de la combinacion, 
	 * y las inserta en dos ArrayLists separados. Luego, llama el constructor
	 * de abajo para crear la clase Combinacion con los ArrayList recién creados.
	 * @param numero1
	 * @param numero2
	 * @param numero3
	 * @param numero4
	 * @param numero5
	 * @param estrella1
	 * @param estrella2
	 */
	public Combinacion (Integer numero1, Integer numero2, 
			Integer numero3, Integer numero4, Integer numero5, 
			Integer estrella1, Integer estrella2) {
		
		Collection<Integer> numeros = new ArrayList<>();
		Collection<Integer> estrellas = new ArrayList<>();
		
		/*Aqui entiendo que se pondría un try/catch para lanzar 
		una Exception si alguno de los numeros es inferior a 1 
		o superior a 12, usando los valores final de arriba.*/
	
		numeros.add(numero1);
		numeros.add(numero2);
		numeros.add(numero3);
		numeros.add(numero4);
		numeros.add(numero5);
		estrellas.add(estrella1);
		estrellas.add(estrella2);
		
		Combinacion combinacion = new Combinacion(numeros, estrellas);
		
	}
	
	/**
	 * Constructor que crea la clase Combinacion, insertando 
	 * las Collections ArrayList de numeros y estrellas que se crean en el 
	 * constructor de arriba.
	 * @param numeros
	 * @param estrellas
	 */
	public Combinacion (Collection<Integer> numeros, Collection<Integer> estrellas) {
		this.numeros = numeros;
		this.estrellas = estrellas;
	}
	
	//Métodos
	public int comprobarCombinacion(Combinacion combinacionRecibida) {
		
		
		return -1;
	}
	
	
	//Getters
	public Collection<Integer> getNumeros() {
		return numeros;
	}
	public Collection<Integer> getEstrellas() {
		return estrellas;
	}


	//hashCode
	@Override
	public int hashCode() {
		return Objects.hash(estrellas, numeros);
	}

	//equals()
	@Override
	public boolean equals(Object obj) {
		boolean sonIguales = false;
		
		Combinacion otro = (Combinacion) obj;

		if (this == otro && this != null) {
				//&& this.equals(this.estrellas, otro.estrellas) 
				//&& this.equals(this.numeros, otro.numeros)) {
			sonIguales = true;
		}
		
			
		return sonIguales;
	}
	
	//toString()
	@Override
	public String toString() {
		return "Combinacion [numeros=" + numeros + ", estrellas=" + estrellas + "]";
	}
	
	
	

}
