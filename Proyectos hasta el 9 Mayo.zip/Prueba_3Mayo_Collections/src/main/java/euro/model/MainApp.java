package main.java.euro.model;

import java.util.ArrayList;
import java.util.List;

public class MainApp {

	public static void main(String[] args) {
		
		Combinacion combinacion1 = new Combinacion(1,2,3,4,5,1,2);
		
		List<Integer> listaNum = new ArrayList<>();
		listaNum.add(1);
		listaNum.add(2);
		listaNum.add(3);
		listaNum.add(4);
		listaNum.add(5);

		List<Integer> listaEstrellas = new ArrayList<>();
		listaEstrellas.add(1);
		listaEstrellas.add(2);
		
		Combinacion combinacion2 = new Combinacion(listaNum, listaEstrellas);

		
	}
}
