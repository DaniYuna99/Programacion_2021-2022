package test.java.modelo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import main.java.modelo.Cadena;

public class CadenaTest {

	@ValueSource(strings = {"Arroba", "Mesa", "Modulo"})
	@ParameterizedTest
	void testNoEsAnagrama (String palabra) {
		Cadena cadena1 = new Cadena(palabra);
		assertEquals(cadena1.esAnagrama(), false);

	}
	
	@ValueSource(strings = {"Abba", "Girafarig", "YYaYY"})
	@ParameterizedTest
	void testEsCapicua (String palabra) {
		Cadena cadena1 = new Cadena(palabra);
		assertEquals(cadena1.esAnagrama(), true);
		//Sale mal por algun motivo.
	}
}
