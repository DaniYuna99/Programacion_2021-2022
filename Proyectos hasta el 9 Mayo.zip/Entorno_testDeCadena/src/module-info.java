module entorno_testDeCadena {
	//requires org.junit.jupiter.api;
	requires org.junit.jupiter.params;
}