package main.java.mercado.modelo;

import java.util.ArrayList;
import java.util.List;

import main.java.supermercado.modelo.Cliente;

public class Caja {
	
	//No lo he copiado todo porque fue martes.

	
	private int idCaja;
	
	private List<Cliente> clientes;
	
	public Caja(int id) {
		idCaja = id;
		clientes = new ArrayList<Cliente>();
	}
}
