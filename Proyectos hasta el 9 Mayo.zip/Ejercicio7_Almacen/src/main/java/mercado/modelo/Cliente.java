package main.java.mercado.modelo;

public class Cliente {
	
	//No lo he copiado todo porque fue martes.

	
	private static int idClienteActual = 0;
	
	private int numeroCliente;
	
	public Cliente() {
		this.numeroCliente = idClienteActual++;
	}

	
	public int getNumeroCliente() {
		return numeroCliente;
	}

	public void setNumeroCliente(int numeroCliente) {
		this.numeroCliente = numeroCliente;
	}

	
}
