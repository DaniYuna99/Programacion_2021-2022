module ejercicio7_Almacen {
}