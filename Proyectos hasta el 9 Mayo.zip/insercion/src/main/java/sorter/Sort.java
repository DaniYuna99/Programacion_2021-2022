package main.java.sorter;

import java.util.List;

public class Sort {
	
	public static List<Integer> ordenarPorInsercion (List<Integer> lista) {
			
		if(lista != null && !lista.isEmpty()) {
			//Vamos a ordenarla
			
			for (int i = 0; i < lista.size(); i++) {
				
				int posicionActual = i;
				boolean posicionEncontrada = false;
				
				while (!posicionEncontrada && posicionActual > 0) {
					if (lista.get(posicionActual - 1) > lista.get(posicionActual)) {
						Integer tmp = lista.get(posicionActual);
						lista.remove(posicionActual);
						lista.add(posicionActual - 1, tmp);
						
						posicionActual--;
						
					}else {
						posicionEncontrada = true;
					}
				}
				
			}
		}
		
		return lista;
	}
}
