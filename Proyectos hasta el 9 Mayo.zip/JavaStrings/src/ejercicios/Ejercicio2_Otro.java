package ejercicios;

public class Ejercicio2_Otro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/* Escribe una función que reciba una cadena de texto y una variable bandera (par/impar) 
		 * e imprima solo los caracteres que se encuentran situados en las posiciones pares e impares (según
		 * indique la variable bandera). Desarrolla el código con un bucle for y después modifica
		 * el código para que utilice un bucle While.
		 * */

	}

}
