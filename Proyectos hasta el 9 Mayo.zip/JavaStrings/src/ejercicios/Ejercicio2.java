package ejercicios;

public class Ejercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/* Escribe una función que reciba una cadena de texto y una variable bandera (par/impar) 
		 * e imprima solo los caracteres que se encuentran situados en las posiciones pares e impares (según
		 * indique la variable bandera). Desarrolla el código con un bucle for y después modifica
		 * el código para que utilice un bucle While.
		 * */
		
		//System.out.println(obtenerCaracteresPares("Hola, mundo", false));
		StringBuilder sb = new StringBuilder("Cadena inicial");
		sb.append(false)
	}
	
	public static String obtenerCaracteresPares (String cadena, boolean par) {
		
		StringBuilder sb = new StringBuilder("Cualquiera");
		
		
			for (int i= (par ? 0: 1) ; i < cadena.length(); i+=2) {
				sb.append(cadena.charAt(i));
			}
		
		return sb.toString();
	}

}
