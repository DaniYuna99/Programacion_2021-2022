package main.java.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainApp {

	public static void main(String[] args) {
		
		leerArchivoTexto("./files/address.txt");
		//File file = new File("./files/address.txt");
		//System.out.println(file.exists());
	}

	public static void leerArchivoTexto(String rutaArchivo) {
		File file = new File(rutaArchivo);
		try {
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			String linea = br.readLine();
			br.readLine();
			
			while (linea != null) {
				System.out.println(linea);
				linea = br.readLine();
				
				String[] info = linea.split(","); 
				List<String> lista = new ArrayList<>();
				lista.add(String.valueOf(info[2]));
				System.out.println(lista);
				
			}

		}catch (FileNotFoundException e) {
			System.out.println("El archivo no existe.");
		}catch (IOException e) {
			System.out.println("IOException ha ocurrido.");
		}
		
	}
}
;